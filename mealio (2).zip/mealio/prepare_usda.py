
import json
import os

INPUT_FILE = "FoodData_Central_foundation_food_json_2026-04-30.json"
OUTPUT_FILE = "assets/usda_foods.json"


def main():
    if not os.path.exists(INPUT_FILE):
        print("Error: USDA JSON file was not found.")
        return

    print("Reading USDA data...")

    with open(INPUT_FILE, "r", encoding="utf-8") as file:
        data = json.load(file)

    foods = data.get("FoundationFoods", [])
    results = []
    categories = set()

    for food in foods:
        if not isinstance(food, dict):
            continue

        description = (food.get("description") or "").strip()

        if not description:
            continue

        category = food.get("foodCategory") or {}

        if isinstance(category, dict):
            category_name = (
                    category.get("description") or ""
            ).strip()
        else:
            category_name = ""

        nutrients = []

        for item in food.get("foodNutrients", []):
            if not isinstance(item, dict):
                continue

            nutrient = item.get("nutrient") or {}

            if not isinstance(nutrient, dict):
                continue

            name = (nutrient.get("name") or "").strip()
            unit = (nutrient.get("unitName") or "").strip()
            amount = item.get("amount")

            if name and amount is not None:
                nutrients.append({
                    "name": name,
                    "unit": unit,
                    "amount": amount,
                })

        results.append({
            "fdcId": food.get("fdcId"),
            "description": description,
            "category": category_name or "Uncategorized",
            "dataType": food.get("dataType", "Foundation"),
            "nutrients": nutrients,
        })

        if category_name:
            categories.add(category_name)

    os.makedirs("assets", exist_ok=True)

    with open(OUTPUT_FILE, "w", encoding="utf-8") as file:
        json.dump(
            {
                "categories": sorted(categories),
                "foods": results,
            },
            file,
            ensure_ascii=False,
            separators=(",", ":"),
        )

    print(f"Foods extracted: {len(results)}")
    print(f"Categories found: {len(categories)}")
    print(f"Output saved to: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
