import 'dart:async';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'login_screen.dart';
import 'bmi_screen.dart';
import 'profile_screen.dart';
import 'meals_screen.dart';
import 'saved_meals_screen.dart';
import 'tips_screen.dart';
import 'meal_data_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final MealDataService mealService = MealDataService();

  String userName = 'User';

  bool isLoading = true;
  bool isLoadingCalories = true;

  double calories = 0;
  double protein = 0;
  double carbs = 0;
  double fat = 0;

  double? dailyCalorieGoal;
  String? calorieGoalError;

  Timer? _dayRefreshTimer;

  int selectedIndex = 0;

  static const Color primaryGreen = Color(0xFF41644A);
  static const Color backgroundColor = Color(0xFFF7F8F2);
  static const Color headingColor = Color(0xFF26382B);
  static const Color lightGreen = Color(0xFFE5EEDD);
  static const Color secondaryGreen = Color(0xFF526653);

  @override
  void initState() {
    super.initState();

    loadUserData();
    loadCalories();
    startDayRefreshTimer();
  }

  String get todayKey {
    final now = DateTime.now();

    return '${now.year}-'
        '${now.month.toString().padLeft(2, '0')}-'
        '${now.day.toString().padLeft(2, '0')}';
  }

  void startDayRefreshTimer() {
    String previousDay = todayKey;

    _dayRefreshTimer = Timer.periodic(const Duration(minutes: 1), (timer) {
      if (todayKey != previousDay) {
        previousDay = todayKey;
        loadCalories();
      }
    });
  }

  double readDouble(dynamic value) {
    if (value is num) return value.toDouble();

    return double.tryParse(value?.toString() ?? '') ?? 0;
  }

  Future<void> loadUserData() async {
    final user = auth.currentUser;

    if (user == null) {
      if (mounted) {
        setState(() => isLoading = false);
      }
      return;
    }

    try {
      final document = await firestore.collection('users').doc(user.uid).get();

      final data = document.data() ?? {};

      final name =
          (data['name'] ?? data['fullName'] ?? user.displayName ?? 'User')
              .toString()
              .trim();

      if (!mounted) return;

      setState(() {
        userName = name.isEmpty ? 'User' : name;
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        userName = user.displayName ?? 'User';
        isLoading = false;
      });
    }
  }

  Future<void> loadCalories() async {
    final user = auth.currentUser;

    if (user == null) {
      if (mounted) {
        setState(() => isLoadingCalories = false);
      }
      return;
    }

    if (mounted) {
      setState(() => isLoadingCalories = true);
    }

    try {
      final document = await firestore.collection('users').doc(user.uid).get();

      final data = document.data() ?? {};

      final weight = readDouble(data['weight']);
      final height = readDouble(data['height']);
      final age = readDouble(data['age']);

      final gender = (data['gender'] ?? 'female').toString().toLowerCase();

      final activityLevel = (data['activityLevel'] ?? 'sedentary')
          .toString()
          .toLowerCase();

      final healthGoal = (data['healthGoal'] ?? 'maintain')
          .toString()
          .toLowerCase();

      final weeklyWeightLoss = readDouble(data['weeklyWeightLoss']);

      double? calculatedGoal;

      if (weight > 0 && height > 0 && age > 0) {
        double bmr;

        if (gender == 'male') {
          bmr = (10 * weight) + (6.25 * height) - (5 * age) + 5;
        } else {
          bmr = (10 * weight) + (6.25 * height) - (5 * age) - 161;
        }

        double activityMultiplier = 1.2;

        if (activityLevel == 'light' || activityLevel == 'lightly active') {
          activityMultiplier = 1.375;
        } else if (activityLevel == 'moderate' ||
            activityLevel == 'moderately active') {
          activityMultiplier = 1.55;
        } else if (activityLevel == 'active' ||
            activityLevel == 'very active') {
          activityMultiplier = 1.725;
        } else if (activityLevel == 'extra active') {
          activityMultiplier = 1.9;
        }

        calculatedGoal = bmr * activityMultiplier;

        if (healthGoal.contains('lose') || healthGoal.contains('loss')) {
          calculatedGoal -=
              (weeklyWeightLoss > 0 ? weeklyWeightLoss : 0.5) * 7700 / 7;
        } else if (healthGoal.contains('gain')) {
          calculatedGoal += 250;
        }

        calculatedGoal = calculatedGoal.clamp(
          gender == 'male' ? 1500.0 : 1200.0,
          5000.0,
        );
      }

      final meals = await mealService.getMeals();
      final totals = await mealService.calculateTotals(meals);

      if (!mounted) return;

      setState(() {
        dailyCalorieGoal = calculatedGoal;

        calories = readDouble(totals['calories']);
        protein = readDouble(totals['protein']);
        carbs = readDouble(totals['carbs']);
        fat = readDouble(totals['fat']);

        calorieGoalError = calculatedGoal == null
            ? 'Please complete your profile details.'
            : null;

        isLoadingCalories = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoadingCalories = false;
        calorieGoalError = 'Unable to load nutrition data.';
      });
    }
  }

  void changePage(int index) {
    if (index < 0 || index > 4) return;

    setState(() {
      selectedIndex = index;
    });

    if (index == 0) {
      loadUserData();
      loadCalories();
    }
  }

  void openBMI() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => BmiScreen()),
    ).then((_) {
      loadUserData();
      loadCalories();
    });
  }

  Future<void> logout() async {
    await auth.signOut();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => LoginScreen()),
      (route) => false,
    );
  }

  // Responsive calories card using LayoutBuilder and Stack.
  Widget buildCaloriesStackCard() {
    final goal = dailyCalorieGoal ?? 0;

    final progress = goal > 0 ? (calories / goal).clamp(0.0, 1.0) : 0.0;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [primaryGreen, secondaryGreen],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: primaryGreen.withOpacity(0.15),
            blurRadius: 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final isNarrow = constraints.maxWidth < 380;

          final circleSize = constraints.maxWidth < 300
              ? 110.0
              : constraints.maxWidth < 450
              ? 125.0
              : 135.0;

          final calorieCircle = SizedBox(
            width: circleSize,
            height: circleSize,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox.expand(
                  child: CircularProgressIndicator(
                    value: progress,
                    strokeWidth: 10,
                    backgroundColor: Colors.white24,
                    valueColor: const AlwaysStoppedAnimation<Color>(lightGreen),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(
                          isLoadingCalories
                              ? '...'
                              : calories.toStringAsFixed(0),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const Text(
                        'kcal eaten',
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );

          final goalDetails = Column(
            crossAxisAlignment: isNarrow
                ? CrossAxisAlignment.center
                : CrossAxisAlignment.start,
            children: [
              const Text(
                'Daily Goal',
                style: TextStyle(color: Colors.white70, fontSize: 14),
              ),
              const SizedBox(height: 5),
              Text(
                isLoadingCalories
                    ? 'Loading...'
                    : goal > 0
                    ? '${goal.toStringAsFixed(0)} kcal'
                    : 'Not set',
                textAlign: isNarrow ? TextAlign.center : TextAlign.start,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                goal > 0
                    ? '${(goal - calories).clamp(0, goal).toStringAsFixed(0)} kcal remaining'
                    : 'Complete your profile to calculate your goal.',
                textAlign: isNarrow ? TextAlign.center : TextAlign.start,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 12,
                  height: 1.4,
                ),
              ),
              if (calorieGoalError != null) ...[
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () => changePage(4),
                  style: TextButton.styleFrom(foregroundColor: Colors.white),
                  child: const Text('Update profile'),
                ),
              ],
            ],
          );

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Today's Calories",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 18),
              if (isNarrow) ...[
                Center(child: calorieCircle),
                const SizedBox(height: 20),
                SizedBox(width: double.infinity, child: goalDetails),
              ] else
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    calorieCircle,
                    const SizedBox(width: 20),
                    Expanded(child: goalDetails),
                  ],
                ),
            ],
          );
        },
      ),
    );
  }

  Widget nutritionCard({
    required String title,
    required String value,
    required String unit,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: lightGreen),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: primaryGreen, size: 23),
          const SizedBox(height: 8),
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: headingColor,
              fontWeight: FontWeight.w600,
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '$value $unit',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: primaryGreen,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  // Responsive nutrition grid.
  Widget buildNutritionGrid() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth >= 600 ? 4 : 2;

        return GridView.count(
          crossAxisCount: columns,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          mainAxisExtent: 120,
          children: [
            nutritionCard(
              title: 'Protein',
              value: protein.toStringAsFixed(1),
              unit: 'g',
              icon: Icons.egg_alt_outlined,
            ),
            nutritionCard(
              title: 'Carbs',
              value: carbs.toStringAsFixed(1),
              unit: 'g',
              icon: Icons.grain,
            ),
            nutritionCard(
              title: 'Fat',
              value: fat.toStringAsFixed(1),
              unit: 'g',
              icon: Icons.water_drop_outlined,
            ),
            nutritionCard(
              title: 'Calories',
              value: calories.toStringAsFixed(0),
              unit: 'kcal',
              icon: Icons.local_fire_department_outlined,
            ),
          ],
        );
      },
    );
  }

  Widget featureCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          width: double.infinity,
          height: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: lightGreen),
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: lightGreen,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: primaryGreen, size: 23),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: headingColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.black54,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildFeatureCards() {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 340) {
          return Column(
            children: [
              SizedBox(
                height: 85,
                width: double.infinity,
                child: featureCard(
                  icon: Icons.restaurant_menu,
                  title: 'Meal Tracker',
                  subtitle: 'Manage your daily food',
                  onTap: () => changePage(1),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 85,
                width: double.infinity,
                child: featureCard(
                  icon: Icons.monitor_weight_outlined,
                  title: 'BMI Calculator',
                  subtitle: 'Check your BMI',
                  onTap: openBMI,
                ),
              ),
            ],
          );
        }

        return Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 85,
                child: featureCard(
                  icon: Icons.restaurant_menu,
                  title: 'Meal Tracker',
                  subtitle: 'Manage your daily food',
                  onTap: () => changePage(1),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: SizedBox(
                height: 85,
                child: featureCard(
                  icon: Icons.monitor_weight_outlined,
                  title: 'BMI Calculator',
                  subtitle: 'Check your BMI',
                  onTap: openBMI,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // Home page content.
  Widget buildHomeContent() {
    return RefreshIndicator(
      onRefresh: () async {
        await loadUserData();
        await loadCalories();
      },
      color: primaryGreen,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
        children: [
          Text(
            isLoading ? 'Hello!' : 'Hello, $userName 👋',
            style: const TextStyle(
              color: headingColor,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            "Let's take care of your health today.",
            style: TextStyle(color: Colors.black54, fontSize: 14),
          ),
          const SizedBox(height: 22),
          buildCaloriesStackCard(),
          const SizedBox(height: 25),
          const Text(
            "Today's Nutrition",
            style: TextStyle(
              color: headingColor,
              fontSize: 19,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 14),
          buildNutritionGrid(),
          const SizedBox(height: 25),
          const Text(
            'Explore Mealio',
            style: TextStyle(
              color: headingColor,
              fontSize: 19,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 14),
          buildFeatureCards(),
          const SizedBox(height: 22),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: lightGreen,
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.eco_outlined, color: primaryGreen, size: 28),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Healthy Reminder',
                        style: TextStyle(
                          color: headingColor,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 6),
                      Text(
                        'Small healthy choices every day can make '
                        'a big difference. Remember to drink water '
                        'and enjoy balanced meals.',
                        style: TextStyle(
                          color: secondaryGreen,
                          fontSize: 13,
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Keep all five pages in the same screen.
  Widget buildSelectedPage() {
    return IndexedStack(
      index: selectedIndex,
      children: [
        buildHomeContent(),
        MealsScreen(),
        SavedMealsScreen(mealService: mealService),
        TipsScreen(),
        const ProfileScreen(),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: selectedIndex == 0
          ? AppBar(
              backgroundColor: backgroundColor,
              elevation: 0,
              title: const Text(
                'Mealio',
                style: TextStyle(
                  color: primaryGreen,
                  fontWeight: FontWeight.bold,
                  fontSize: 25,
                ),
              ),
              actions: [
                IconButton(
                  onPressed: logout,
                  icon: const Icon(Icons.logout, color: primaryGreen),
                  tooltip: 'Logout',
                ),
              ],
            )
          : null,
      body: buildSelectedPage(),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: selectedIndex,
        selectedItemColor: primaryGreen,
        unselectedItemColor: Colors.grey,
        backgroundColor: Colors.white,
        showUnselectedLabels: true,
        onTap: changePage,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.restaurant_menu),
            activeIcon: Icon(Icons.restaurant),
            label: 'Meals',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bookmark_border),
            activeIcon: Icon(Icons.bookmark),
            label: 'Saved Meals',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.lightbulb_outline),
            activeIcon: Icon(Icons.lightbulb),
            label: 'Tips',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
