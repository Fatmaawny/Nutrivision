import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'home_screen.dart';

class CompleteProfileScreen extends StatefulWidget {
  const CompleteProfileScreen({super.key});

  @override
  State<CompleteProfileScreen> createState() => _CompleteProfileScreenState();
}

class _CompleteProfileScreenState extends State<CompleteProfileScreen> {
  final formKey = GlobalKey<FormState>();

  final ageController = TextEditingController();
  final heightController = TextEditingController();
  final weightController = TextEditingController();
  final targetWeightController = TextEditingController();
  final otherAllergyController = TextEditingController();

  static const Color green = Color(0xFF21865B);
  static const Color darkGreen = Color(0xFF145638);
  static const Color cream = Color(0xFFFCFCF7);
  static const Color muted = Color(0xFF718078);

  String? gender;
  String? activityLevel;
  String? healthGoal;
  String? dietaryPreference;
  double? weeklyWeightLoss;

  final Set<String> selectedAllergies = {};

  bool isLoading = false;

  final List<String> allergyOptions = [
    'None',
    'Milk',
    'Eggs',
    'Peanuts',
    'Tree Nuts',
    'Fish',
    'Shellfish',
    'Soy',
    'Wheat',
    'Sesame',
    'Other',
  ];

  bool get needsTargetWeight =>
      healthGoal == 'Lose Weight' || healthGoal == 'Gain Weight';

  String? get weeklyWeightLossValue {
    if (weeklyWeightLoss == null) return null;

    for (final option in ['0.25', '0.5', '0.75', '1.0']) {
      if (double.parse(option) == weeklyWeightLoss) {
        return option;
      }
    }

    return null;
  }

  void showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: darkGreen),
    );
  }

  double? parseNumber(String value) {
    return double.tryParse(value.trim().replaceAll(',', '.'));
  }

  void toggleAllergy(String allergy) {
    setState(() {
      if (allergy == 'None') {
        if (selectedAllergies.contains('None')) {
          selectedAllergies.remove('None');
        } else {
          selectedAllergies
            ..clear()
            ..add('None');
          otherAllergyController.clear();
        }
        return;
      }

      selectedAllergies.remove('None');

      if (selectedAllergies.contains(allergy)) {
        selectedAllergies.remove(allergy);

        if (allergy == 'Other') {
          otherAllergyController.clear();
        }
      } else {
        selectedAllergies.add(allergy);
      }
    });
  }

  Future<void> saveProfile() async {
    FocusScope.of(context).unfocus();

    if (!formKey.currentState!.validate()) return;

    if (gender == null ||
        activityLevel == null ||
        healthGoal == null ||
        dietaryPreference == null) {
      showMessage('Please complete all profile selections.');
      return;
    }

    if (selectedAllergies.isEmpty) {
      showMessage('Please select your food allergies or None.');
      return;
    }

    if (selectedAllergies.contains('Other') &&
        otherAllergyController.text.trim().isEmpty) {
      showMessage('Please specify your other allergy.');
      return;
    }

    if (healthGoal == 'Lose Weight' && weeklyWeightLoss == null) {
      showMessage('Please select your weekly weight loss goal.');
      return;
    }

    final currentWeight = parseNumber(weightController.text);
    final height = parseNumber(heightController.text);
    final targetWeight = needsTargetWeight
        ? parseNumber(targetWeightController.text)
        : null;

    if (currentWeight == null ||
        !currentWeight.isFinite ||
        currentWeight <= 0) {
      showMessage('Please enter a valid current weight.');
      return;
    }

    if (height == null || !height.isFinite || height <= 0) {
      showMessage('Please enter a valid height.');
      return;
    }

    if (needsTargetWeight &&
        (targetWeight == null || !targetWeight.isFinite || targetWeight <= 0)) {
      showMessage('Please enter a valid target weight.');
      return;
    }

    if (healthGoal == 'Lose Weight' &&
        targetWeight != null &&
        targetWeight >= currentWeight) {
      showMessage('Target weight must be below your current weight.');
      return;
    }

    if (healthGoal == 'Gain Weight' &&
        targetWeight != null &&
        targetWeight <= currentWeight) {
      showMessage('Target weight must be above your current weight.');
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      final user = FirebaseAuth.instance.currentUser;

      if (user == null) {
        throw Exception('No user is currently logged in.');
      }

      final allergies = selectedAllergies
          .where((allergy) => allergy != 'Other')
          .toList();

      if (selectedAllergies.contains('Other')) {
        allergies.add('Other: ${otherAllergyController.text.trim()}');
      }

      final Map<String, dynamic> profileData = {
        'age': int.parse(ageController.text.trim()),
        'gender': gender,
        'height': height,
        'weight': currentWeight,
        'activityLevel': activityLevel,
        'healthGoal': healthGoal,
        'foodAllergies': allergies,
        'dietaryPreference': dietaryPreference,
        'targetWeight': targetWeight,
        'weeklyWeightLoss': healthGoal == 'Lose Weight'
            ? weeklyWeightLoss
            : null,
        'profileCompleted': true,
        'updatedAt': FieldValue.serverTimestamp(),
      };

      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .set(profileData, SetOptions(merge: true));

      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    } on FirebaseException catch (e) {
      showMessage('Could not save profile: ${e.message ?? e.code}');
    } catch (e) {
      showMessage('Could not save profile: $e');
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Widget buildResponsiveGrid({
    required bool isWide,
    required List<Widget> children,
  }) {
    return GridView(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: isWide ? 2 : 1,
        crossAxisSpacing: 16,
        mainAxisSpacing: 0,
        mainAxisExtent: 88,
      ),
      children: children,
    );
  }

  Widget buildSectionTitle(String title, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(top: 22, bottom: 12),
      child: Row(
        children: [
          Icon(icon, color: green, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                color: darkGreen,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildInput({
    required String label,
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    required TextInputType keyboardType,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      textInputAction: TextInputAction.next,
      validator:
          validator ??
          (value) {
            if (value == null || value.trim().isEmpty) {
              return 'This field is required';
            }

            final number = parseNumber(value);

            if (number == null || !number.isFinite || number <= 0) {
              return 'Enter a valid number';
            }

            return null;
          },
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon, color: green),
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 15,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: green.withOpacity(0.2)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: green.withOpacity(0.2)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: green, width: 1.5),
        ),
      ),
    );
  }

  Widget buildDropdown({
    required String label,
    required String? value,
    required List<String> options,
    required IconData icon,
    required void Function(String?) onChanged,
  }) {
    final uniqueOptions = options.toSet().toList();

    final safeValue = value != null && uniqueOptions.contains(value)
        ? value
        : null;

    return DropdownButtonFormField<String>(
      key: ValueKey('$label-${safeValue ?? 'empty'}'),
      initialValue: safeValue,
      isExpanded: true,

      dropdownColor: const Color(0xFFF1F5EE),
      borderRadius: BorderRadius.circular(14),
      menuMaxHeight: 280,
      style: const TextStyle(color: Color(0xFF145638), fontSize: 14),
      iconEnabledColor: const Color(0xFF21865B),

      validator: (selectedValue) {
        if (selectedValue == null || selectedValue.isEmpty) {
          return 'Please select an option';
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: green),
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: green.withOpacity(0.2)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: green.withOpacity(0.2)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: green, width: 1.5),
        ),
      ),
      items: uniqueOptions.map((option) {
        return DropdownMenuItem<String>(
          value: option,
          child: Text(
            option,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Color(0xFF145638)),
          ),
        );
      }).toList(),
      onChanged: onChanged,
    );
  }

  Widget buildAllergySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildSectionTitle('Food Allergies', Icons.health_and_safety_outlined),
        const Text(
          'Select all that apply.',
          style: TextStyle(color: muted, fontSize: 14),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: allergyOptions.map((allergy) {
            final selected = selectedAllergies.contains(allergy);

            return FilterChip(
              label: Text(allergy),
              selected: selected,
              onSelected: (_) => toggleAllergy(allergy),
              selectedColor: green.withOpacity(0.18),
              checkmarkColor: darkGreen,
              labelStyle: TextStyle(
                color: selected ? darkGreen : Colors.black87,
                fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: BorderSide(
                  color: selected ? green : green.withOpacity(0.25),
                ),
              ),
            );
          }).toList(),
        ),
        if (selectedAllergies.contains('Other')) ...[
          const SizedBox(height: 16),
          TextFormField(
            controller: otherAllergyController,
            textCapitalization: TextCapitalization.sentences,
            validator: (value) {
              if (selectedAllergies.contains('Other') &&
                  (value == null || value.trim().isEmpty)) {
                return 'Please specify your allergy';
              }
              return null;
            },
            decoration: InputDecoration(
              labelText: 'Specify other allergy',
              hintText: 'e.g. Strawberries',
              prefixIcon: const Icon(Icons.edit_outlined, color: green),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(color: green.withOpacity(0.2)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: const BorderSide(color: green, width: 1.5),
              ),
            ),
          ),
        ],
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cream,
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        title: const Text(
          'Complete Your Profile',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: cream,
        foregroundColor: darkGreen,
        elevation: 0,
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final isWide = constraints.maxWidth >= 700;

            return Form(
              key: formKey,
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(
                  horizontal: isWide ? 32 : 20,
                  vertical: 20,
                ),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 900),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        SizedBox(
                          height: 125,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                left: isWide ? 180 : 20,
                                top: 10,
                                child: Container(
                                  width: 45,
                                  height: 45,
                                  decoration: BoxDecoration(
                                    color: green.withOpacity(0.10),
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                ),
                              ),
                              Positioned(
                                right: isWide ? 180 : 25,
                                top: 20,
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: green.withOpacity(0.15),
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 60,
                                    height: 60,
                                    decoration: BoxDecoration(
                                      color: green.withOpacity(0.10),
                                      borderRadius: BorderRadius.circular(19),
                                    ),
                                    child: const Icon(
                                      Icons.restaurant_menu_rounded,
                                      color: green,
                                      size: 35,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  const Text(
                                    'Mealio',
                                    style: TextStyle(
                                      color: darkGreen,
                                      fontSize: 23,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                        Text(
                          'Complete Your Profile',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: darkGreen,
                            fontSize: isWide ? 28 : 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Help us personalize your nutrition journey.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: muted, fontSize: 14),
                        ),

                        buildSectionTitle(
                          'Personal Information',
                          Icons.person_outline,
                        ),

                        buildResponsiveGrid(
                          isWide: isWide,
                          children: [
                            buildInput(
                              label: 'Age',
                              controller: ageController,
                              hint: 'Enter your age',
                              icon: Icons.cake_outlined,
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                final age = int.tryParse((value ?? '').trim());

                                if (age == null || age < 1 || age > 120) {
                                  return 'Enter a valid age';
                                }
                                return null;
                              },
                            ),
                            buildDropdown(
                              label: 'Gender',
                              value: gender,
                              options: const [
                                'Female',
                                'Male',
                                'Prefer not to say',
                              ],
                              icon: Icons.wc,
                              onChanged: (value) {
                                setState(() {
                                  gender = value;
                                });
                              },
                            ),
                          ],
                        ),

                        buildSectionTitle(
                          'Body Measurements',
                          Icons.monitor_weight_outlined,
                        ),

                        buildResponsiveGrid(
                          isWide: isWide,
                          children: [
                            buildInput(
                              label: 'Height (cm)',
                              controller: heightController,
                              hint: 'e.g. 165',
                              icon: Icons.height,
                              keyboardType:
                                  const TextInputType.numberWithOptions(
                                    decimal: true,
                                  ),
                            ),
                            buildInput(
                              label: 'Current Weight (kg)',
                              controller: weightController,
                              hint: 'e.g. 65',
                              icon: Icons.monitor_weight_outlined,
                              keyboardType:
                                  const TextInputType.numberWithOptions(
                                    decimal: true,
                                  ),
                            ),
                          ],
                        ),

                        buildSectionTitle('Lifestyle', Icons.directions_walk),

                        buildResponsiveGrid(
                          isWide: isWide,
                          children: [
                            buildDropdown(
                              label: 'Activity Level',
                              value: activityLevel,
                              options: const [
                                'Sedentary',
                                'Lightly active',
                                'Moderately active',
                                'Very active',
                                'Extra active',
                              ],
                              icon: Icons.directions_run,
                              onChanged: (value) {
                                setState(() {
                                  activityLevel = value;
                                });
                              },
                            ),
                          ],
                        ),

                        buildSectionTitle('Health Goal', Icons.flag_outlined),

                        buildResponsiveGrid(
                          isWide: isWide,
                          children: [
                            buildDropdown(
                              label: 'What is your goal?',
                              value: healthGoal,
                              options: const [
                                'Lose Weight',
                                'Maintain Weight',
                                'Gain Weight',
                                'Eat Healthier',
                              ],
                              icon: Icons.track_changes,
                              onChanged: (value) {
                                setState(() {
                                  healthGoal = value;
                                  weeklyWeightLoss = null;

                                  if (!needsTargetWeight) {
                                    targetWeightController.clear();
                                  }
                                });
                              },
                            ),
                            if (needsTargetWeight)
                              buildInput(
                                label: 'Target Weight (kg)',
                                controller: targetWeightController,
                                hint: 'Enter your target weight',
                                icon: Icons.monitor_weight,
                                keyboardType:
                                    const TextInputType.numberWithOptions(
                                      decimal: true,
                                    ),
                                validator: (value) {
                                  if (!needsTargetWeight) return null;

                                  final target = parseNumber(value ?? '');
                                  final current = parseNumber(
                                    weightController.text,
                                  );

                                  if (target == null ||
                                      !target.isFinite ||
                                      target <= 0) {
                                    return 'Enter a valid target weight';
                                  }

                                  if (current != null &&
                                      healthGoal == 'Lose Weight' &&
                                      target >= current) {
                                    return 'Must be below current weight';
                                  }

                                  if (current != null &&
                                      healthGoal == 'Gain Weight' &&
                                      target <= current) {
                                    return 'Must be above current weight';
                                  }

                                  return null;
                                },
                              ),
                            if (healthGoal == 'Lose Weight')
                              buildDropdown(
                                label: 'Weekly Weight Loss (kg)',
                                value: weeklyWeightLossValue,
                                options: const ['0.25', '0.5', '0.75', '1.0'],
                                icon: Icons.trending_down,
                                onChanged: (value) {
                                  setState(() {
                                    weeklyWeightLoss = value == null
                                        ? null
                                        : double.tryParse(value);
                                  });
                                },
                              ),
                          ],
                        ),

                        if (healthGoal == 'Lose Weight')
                          const Padding(
                            padding: EdgeInsets.only(bottom: 8),
                            child: Text(
                              'Choose your desired weekly weight loss. '
                              'The maximum option is 1 kg per week.',
                              style: TextStyle(
                                color: muted,
                                fontSize: 13,
                                height: 1.5,
                              ),
                            ),
                          ),

                        buildAllergySection(),

                        buildSectionTitle(
                          'Dietary Preference',
                          Icons.restaurant_menu,
                        ),

                        buildResponsiveGrid(
                          isWide: isWide,
                          children: [
                            buildDropdown(
                              label: 'Your dietary preference',
                              value: dietaryPreference,
                              options: const [
                                'No Restrictions',
                                'Vegetarian',
                                'Vegan',
                                'Pescatarian',
                              ],
                              icon: Icons.eco_outlined,
                              onChanged: (value) {
                                setState(() {
                                  dietaryPreference = value;
                                });
                              },
                            ),
                          ],
                        ),

                        const SizedBox(height: 20),

                        SizedBox(
                          height: 54,
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: isLoading ? null : saveProfile,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: green,
                              foregroundColor: Colors.white,
                              disabledBackgroundColor: green.withOpacity(0.6),
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15),
                              ),
                            ),
                            child: isLoading
                                ? const SizedBox(
                                    width: 23,
                                    height: 23,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2.5,
                                    ),
                                  )
                                : const Text(
                                    'Save Profile',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                          ),
                        ),

                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
