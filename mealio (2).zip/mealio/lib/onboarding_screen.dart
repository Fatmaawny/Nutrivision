import 'package:flutter/material.dart';
import 'package:animate_do/animate_do.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:animated_toggle_switch/animated_toggle_switch.dart';

import 'login_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController pageController = PageController();

  int currentPage = 0;

  static const Color primaryGreen = Color(0xFF21865B);
  static const Color darkGreen = Color(0xFF145638);
  static const Color backgroundColor = Color(0xFFFCFCF7);

  final List<Map<String, String>> pages = [
    {
      'title': 'Discover\nHealthy Recipes',
      'description':
          'Get personalized recipe suggestions\nbased on the ingredients you have.',
      'image':
          'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=1200&q=85',
    },
    {
      'title': 'Analyze Your\nNutrition',
      'description':
          'Understand your meals and track\nyour daily nutritional intake.',
      'image':
          'https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=1200&q=85',
    },
    {
      'title': 'Build Healthy\nHabits',
      'description':
          'Get smart recommendations to\nsupport your healthy lifestyle.',
      'image':
          'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=1200&q=85',
    },
  ];

  void nextPage() {
    if (currentPage < pages.length - 1) {
      pageController.nextPage(
        duration: const Duration(milliseconds: 550),
        curve: Curves.easeInOutCubic,
      );
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final width = constraints.maxWidth;
            final height = constraints.maxHeight;

            final isWide = width >= 700;
            final isShort = height < 650;

            final horizontalPadding = isWide ? 40.0 : 16.0;
            final imageHeight = (height * (isWide ? 0.46 : 0.43)).clamp(
              180.0,
              isWide ? 420.0 : 360.0,
            );

            final titleSize = isWide
                ? 34.0
                : isShort
                ? 23.0
                : 27.0;

            final descriptionSize = isWide ? 16.0 : 13.0;
            final buttonHeight = isShort ? 44.0 : 48.0;

            return Stack(
              children: [
                // Decorative background shapes.
                Positioned(
                  top: -25,
                  right: -35,
                  child: _buildLeafDecoration(isWide ? 160 : 110),
                ),
                Positioned(
                  bottom: 20,
                  left: -35,
                  child: Transform.rotate(
                    angle: 2.8,
                    child: _buildLeafDecoration(isWide ? 150 : 100),
                  ),
                ),

                SingleChildScrollView(
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 1000),
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: horizontalPadding,
                          vertical: isShort ? 8 : 12,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // Responsive image carousel.
                            SizedBox(
                              height: imageHeight,
                              width: double.infinity,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(
                                  isWide ? 32 : 26,
                                ),
                                child: PageView.builder(
                                  controller: pageController,
                                  itemCount: pages.length,
                                  onPageChanged: (index) {
                                    setState(() {
                                      currentPage = index;
                                    });
                                  },
                                  itemBuilder: (context, index) {
                                    return Stack(
                                      fit: StackFit.expand,
                                      children: [
                                        Image.network(
                                          pages[index]['image']!,
                                          fit: BoxFit.cover,
                                          loadingBuilder:
                                              (
                                                context,
                                                child,
                                                loadingProgress,
                                              ) {
                                                if (loadingProgress == null) {
                                                  return child
                                                      .animate(
                                                        key: ValueKey(
                                                          'photo-animation-$index',
                                                        ),
                                                      )
                                                      .fadeIn(
                                                        duration:
                                                            const Duration(
                                                              milliseconds: 650,
                                                            ),
                                                      )
                                                      .scale(
                                                        begin: const Offset(
                                                          1.08,
                                                          1.08,
                                                        ),
                                                        end: const Offset(1, 1),
                                                        duration:
                                                            const Duration(
                                                              milliseconds: 900,
                                                            ),
                                                        curve:
                                                            Curves.easeOutCubic,
                                                      );
                                                }

                                                return const ColoredBox(
                                                  color: Color(0xFFE8EEE5),
                                                  child: Center(
                                                    child:
                                                        CircularProgressIndicator(
                                                          color: primaryGreen,
                                                        ),
                                                  ),
                                                );
                                              },
                                          errorBuilder:
                                              (context, error, stackTrace) {
                                                return const ColoredBox(
                                                  color: Color(0xFFE8EEE5),
                                                  child: Center(
                                                    child: Icon(
                                                      Icons
                                                          .restaurant_menu_rounded,
                                                      color: primaryGreen,
                                                      size: 55,
                                                    ),
                                                  ),
                                                );
                                              },
                                        ),

                                        Container(
                                          decoration: BoxDecoration(
                                            gradient: LinearGradient(
                                              begin: Alignment.topCenter,
                                              end: Alignment.bottomCenter,
                                              colors: [
                                                Colors.black.withValues(
                                                  alpha: 0.04,
                                                ),
                                                Colors.transparent,
                                                Colors.black.withValues(
                                                  alpha: 0.18,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),

                                        Positioned(
                                          top: isWide ? 22 : 18,
                                          right: isWide ? 22 : 18,
                                          child: FadeInDown(
                                            key: ValueKey('leaf-top-$index'),
                                            duration: const Duration(
                                              milliseconds: 650,
                                            ),
                                            child: Container(
                                              padding: EdgeInsets.all(
                                                isWide ? 12 : 10,
                                              ),
                                              decoration: BoxDecoration(
                                                color: Colors.white.withValues(
                                                  alpha: 0.88,
                                                ),
                                                shape: BoxShape.circle,
                                              ),
                                              child: Icon(
                                                Icons.eco_rounded,
                                                color: primaryGreen,
                                                size: isWide ? 28 : 24,
                                              ),
                                            ),
                                          ),
                                        ),

                                        Positioned(
                                          bottom: isWide ? 22 : 18,
                                          left: isWide ? 22 : 18,
                                          child: FadeInUp(
                                            key: ValueKey('leaf-bottom-$index'),
                                            duration: const Duration(
                                              milliseconds: 700,
                                            ),
                                            child: Container(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 13,
                                                    vertical: 9,
                                                  ),
                                              decoration: BoxDecoration(
                                                color: Colors.white.withValues(
                                                  alpha: 0.90,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(22),
                                              ),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  const Icon(
                                                    Icons.spa_rounded,
                                                    color: primaryGreen,
                                                    size: 17,
                                                  ),
                                                  const SizedBox(width: 6),
                                                  Text(
                                                    'Healthy Living',
                                                    style: TextStyle(
                                                      color: darkGreen,
                                                      fontSize: isWide
                                                          ? 14
                                                          : 12,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                ),
                              ),
                            ),

                            SizedBox(height: isShort ? 16 : 22),

                            FadeInUp(
                              key: ValueKey('title-$currentPage'),
                              duration: const Duration(milliseconds: 500),
                              from: 24,
                              child: Text(
                                pages[currentPage]['title']!,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: darkGreen,
                                  fontSize: titleSize,
                                  height: 1.18,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: -0.5,
                                ),
                              ),
                            ),

                            SizedBox(height: isShort ? 8 : 12),

                            FadeIn(
                              key: ValueKey('description-$currentPage'),
                              duration: const Duration(milliseconds: 650),
                              delay: const Duration(milliseconds: 120),
                              child: Text(
                                pages[currentPage]['description']!,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: const Color(0xFF777D75),
                                  fontSize: descriptionSize,
                                  height: 1.6,
                                ),
                              ),
                            ),

                            SizedBox(height: isShort ? 18 : 26),

                            AnimatedToggleSwitch<int>.rolling(
                              current: currentPage,
                              values: const [0, 1, 2],
                              onChanged: (index) {
                                pageController.animateToPage(
                                  index,
                                  duration: const Duration(milliseconds: 500),
                                  curve: Curves.easeInOutCubic,
                                );
                              },
                              height: 10,
                              indicatorSize: const Size(10, 10),
                              borderWidth: 0,
                              spacing: 7,
                              style: const ToggleStyle(
                                backgroundColor: Colors.transparent,
                                indicatorColor: primaryGreen,
                                borderColor: Colors.transparent,
                              ),
                              iconBuilder: (value, foreground) {
                                return Container(
                                  width: 8,
                                  height: 8,
                                  decoration: BoxDecoration(
                                    color: value == currentPage
                                        ? primaryGreen
                                        : const Color(0xFFD6DDD5),
                                    shape: BoxShape.circle,
                                  ),
                                );
                              },
                            ),

                            SizedBox(height: isShort ? 16 : 24),

                            SizedBox(
                              width: double.infinity,
                              height: buttonHeight,
                              child: ElevatedButton(
                                onPressed: nextPage,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: primaryGreen,
                                  foregroundColor: Colors.white,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30),
                                  ),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      currentPage == pages.length - 1
                                          ? 'Get Started'
                                          : 'Next',
                                      style: TextStyle(
                                        fontSize: isWide ? 16 : 14,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    const Icon(
                                      Icons.arrow_forward_rounded,
                                      size: 18,
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            const SizedBox(height: 10),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildLeafDecoration(double size) {
    return Icon(Icons.eco, size: size, color: const Color(0xFFDDEACB));
  }
}
