
import 'package:flutter/material.dart';

const Color primaryGreen = Color(0xFF41644A);
const Color backgroundColor = Color(0xFFF7F8F2);
const Color headingColor = Color(0xFF26382B);
const Color lightGreen = Color(0xFFE5EEDD);
const Color secondaryGreen = Color(0xFF526653);

class TipsScreen extends StatelessWidget {
  TipsScreen({super.key});

  final List<Map<String, dynamic>> tips = [
    {
      'icon': Icons.water_drop_outlined,
      'title': 'Stay Hydrated',
      'description':
      'Drink enough water throughout the day to support your health.',
    },
    {
      'icon': Icons.restaurant_outlined,
      'title': 'Eat Balanced Meals',
      'description':
      'Include vegetables, fruits, proteins, and whole grains in your meals.',
    },
    {
      'icon': Icons.directions_walk_outlined,
      'title': 'Stay Active',
      'description':
      'Try to move your body daily, even with a short walk.',
    },
    {
      'icon': Icons.bedtime_outlined,
      'title': 'Get Enough Sleep',
      'description':
      'Maintain a regular sleep schedule to support your well-being.',
    },
    {
      'icon': Icons.spa_outlined,
      'title': 'Manage Stress',
      'description':
      'Take breaks and practice relaxing activities during your day.',
    },
    {
      'icon': Icons.favorite_border,
      'title': 'Build Healthy Habits',
      'description':
      'Make small, consistent changes to improve your lifestyle.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: backgroundColor,
        elevation: 0,
        centerTitle: false,
        title: const Text(
          'Health Tips',
          style: TextStyle(
            color: headingColor,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        iconTheme: const IconThemeData(color: headingColor),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          double horizontalPadding =
          constraints.maxWidth >= 800 ? 32 : 18;

          return SingleChildScrollView(
            padding: EdgeInsets.symmetric(
              horizontal: horizontalPadding,
              vertical: 16,
            ),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1200),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    buildWelcomeCard(constraints.maxWidth),
                    const SizedBox(height: 28),
                    const Text(
                      'Tips for a Healthier Life',
                      style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.bold,
                        color: headingColor,
                      ),
                    ),
                    const SizedBox(height: 16),
                    buildTipsGrid(constraints.maxWidth),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget buildWelcomeCard(double width) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(width < 400 ? 20 : 26),
      decoration: BoxDecoration(
        color: primaryGreen,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Stack(
        children: [
          Positioned(
            right: -8,
            bottom: -20,
            child: Icon(
              Icons.spa_outlined,
              size: width < 400 ? 90 : 120,
              color: Colors.white.withOpacity(0.10),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 10, bottom: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(
                  Icons.eco_outlined,
                  color: Colors.white,
                  size: 34,
                ),
                const SizedBox(height: 14),
                Text(
                  'Small Steps, Healthier You!',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: width < 400 ? 21 : 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Discover simple daily habits that can help you '
                      'improve your nutrition and overall well-being.',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                    height: 1.6,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildTipsGrid(double width) {
    int crossAxisCount;

    if (width >= 1000) {
      crossAxisCount = 3;
    } else if (width >= 600) {
      crossAxisCount = 2;
    } else {
      crossAxisCount = 1;
    }

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: tips.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        crossAxisSpacing: 14,
        mainAxisSpacing: 14,
        mainAxisExtent: width < 400 ? 160 : 145,
      ),
      itemBuilder: (context, index) {
        return buildTipCard(tips[index]);
      },
    );
  }

  Widget buildTipCard(Map<String, dynamic> tip) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: lightGreen,
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: primaryGreen.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: lightGreen,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              tip['icon'] as IconData,
              color: primaryGreen,
              size: 25,
            ),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  tip['title'] as String,
                  style: const TextStyle(
                    color: headingColor,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 7),
                Expanded(
                  child: Text(
                    tip['description'] as String,
                    style: const TextStyle(
                      color: secondaryGreen,
                      fontSize: 13,
                      height: 1.45,
                    ),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
