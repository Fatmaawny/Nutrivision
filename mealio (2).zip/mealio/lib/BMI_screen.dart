import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

const Color primaryGreen = Color(0xFF21865B);
const Color darkGreen = Color(0xFF145638);
const Color backgroundColor = Color(0xFFFCFCF7);
const Color mutedColor = Color(0xFF718078);

class BmiScreen extends StatelessWidget {
  const BmiScreen({super.key});

  double calculateBmi(double weight, double heightCm) {
    double heightM = heightCm / 100;
    return weight / (heightM * heightM);
  }

  String getBmiCategory(double bmi) {
    if (bmi < 18.5) return 'Underweight';
    if (bmi < 25) return 'Normal Weight';
    if (bmi < 30) return 'Overweight';
    return 'Obesity';
  }

  Color getBmiColor(double bmi) {
    if (bmi < 18.5) return Colors.blue;
    if (bmi < 25) return primaryGreen;
    if (bmi < 30) return Colors.orange;
    return Colors.red;
  }

  String getBmiAdvice(double bmi) {
    if (bmi < 18.5) {
      return 'Your BMI is below the healthy range. Consider discussing your nutrition needs with a healthcare professional.';
    } else if (bmi < 25) {
      return 'Your BMI is within the standard healthy range. Keep maintaining balanced meals and regular physical activity.';
    } else if (bmi < 30) {
      return 'Your BMI is above the standard healthy range. Balanced nutrition and regular physical activity may help.';
    } else {
      return 'Your BMI is in the obesity range. Consider speaking with a healthcare professional for personalized guidance.';
    }
  }

  double getActivityMultiplier(dynamic activityLevel) {
    if (activityLevel is num) {
      if (activityLevel >= 1 && activityLevel <= 5) {
        const multipliers = [1.2, 1.375, 1.55, 1.725, 1.9];
        return multipliers[activityLevel.toInt() - 1];
      }

      if (activityLevel >= 1.2 && activityLevel <= 1.9) {
        return activityLevel.toDouble();
      }
    }

    String activity =
        activityLevel?.toString().trim().toLowerCase() ?? 'sedentary';

    switch (activity) {
      case 'lightly active':
        return 1.375;
      case 'moderately active':
        return 1.55;
      case 'very active':
        return 1.725;
      case 'extra active':
        return 1.9;
      case 'sedentary':
      default:
        return 1.2;
    }
  }

  double calculateCalories({
    required double weight,
    required double height,
    required int age,
    required String gender,
    required double activityMultiplier,
    required String healthGoal,
    required double? targetWeight,
    required double weeklyWeightLoss,
  }) {
    double calculationWeight = weight;

    if ((healthGoal == 'Lose Weight' || healthGoal == 'Gain Weight') &&
        targetWeight != null &&
        targetWeight > 0) {
      calculationWeight = targetWeight;
    }

    double bmr;

    if (gender.toLowerCase() == 'male') {
      bmr = (10 * calculationWeight) + (6.25 * height) - (5 * age) + 5;
    } else {
      bmr = (10 * calculationWeight) + (6.25 * height) - (5 * age) - 161;
    }

    double maintenanceCalories = bmr * activityMultiplier;
    double dailyCalories = maintenanceCalories;

    if (healthGoal == 'Lose Weight') {
      dailyCalories -= (weeklyWeightLoss * 7700) / 7;
    } else if (healthGoal == 'Gain Weight') {
      dailyCalories += 250;
    }

    double minimumCalories = gender.toLowerCase() == 'male' ? 1500 : 1200;

    if (dailyCalories < minimumCalories) {
      dailyCalories = minimumCalories;
    }

    return dailyCalories;
  }

  Widget buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, top: 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: darkGreen,
        ),
      ),
    );
  }

  Widget measurementCard({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: primaryGreen.withOpacity(0.12)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: primaryGreen.withOpacity(0.1),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(icon, color: primaryGreen, size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(fontSize: 13, color: mutedColor),
                ),
                const SizedBox(height: 5),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Text(
                    value,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: darkGreen,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget bmiRangeScale(double bmi) {
    const double minBmi = 15;
    const double maxBmi = 40;

    double clampedBmi = bmi.clamp(minBmi, maxBmi).toDouble();
    double position = (clampedBmi - minBmi) / (maxBmi - minBmi);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            double markerWidth = 34;
            double availableWidth = (constraints.maxWidth - markerWidth).clamp(
              0.0,
              double.infinity,
            );

            return SizedBox(
              height: 65,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 28,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Row(
                        children: [
                          Expanded(
                            flex: 14,
                            child: Container(height: 16, color: Colors.blue),
                          ),
                          Expanded(
                            flex: 26,
                            child: Container(height: 16, color: Colors.green),
                          ),
                          Expanded(
                            flex: 20,
                            child: Container(height: 16, color: Colors.orange),
                          ),
                          Expanded(
                            flex: 40,
                            child: Container(height: 16, color: Colors.red),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    left: availableWidth * position,
                    top: 0,
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 7,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: darkGreen,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            bmi.toStringAsFixed(1),
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ),
                        Container(width: 3, height: 15, color: darkGreen),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        const Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('15', style: TextStyle(fontSize: 11, color: mutedColor)),
            Text('18.5', style: TextStyle(fontSize: 11, color: mutedColor)),
            Text('25', style: TextStyle(fontSize: 11, color: mutedColor)),
            Text('30', style: TextStyle(fontSize: 11, color: mutedColor)),
            Text('40', style: TextStyle(fontSize: 11, color: mutedColor)),
          ],
        ),
        const SizedBox(height: 12),
        const Wrap(
          spacing: 12,
          runSpacing: 8,
          children: [
            _BmiLegend(color: Colors.blue, label: 'Underweight'),
            _BmiLegend(color: Colors.green, label: 'Normal'),
            _BmiLegend(color: Colors.orange, label: 'Overweight'),
            _BmiLegend(color: Colors.red, label: 'Obesity'),
          ],
        ),
      ],
    );
  }

  Widget infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(color: mutedColor, fontSize: 14),
            ),
          ),
          const SizedBox(width: 12),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: const TextStyle(
                color: darkGreen,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildInfoCard({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: primaryGreen.withOpacity(0.12)),
      ),
      child: child,
    );
  }

  Widget buildErrorMessage(String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.monitor_heart_outlined,
              size: 55,
              color: primaryGreen,
            ),
            const SizedBox(height: 16),
            const Text(
              'Your BMI Dashboard',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: darkGreen,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: mutedColor, fontSize: 15),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    User? user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      return Scaffold(
        backgroundColor: backgroundColor,
        appBar: AppBar(
          title: const Text('BMI & Calories'),
          backgroundColor: backgroundColor,
          foregroundColor: darkGreen,
          elevation: 0,
        ),
        body: buildErrorMessage(
          'Please log in to view your BMI and calorie information.',
        ),
      );
    }

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        title: const Text(
          'BMI & Calories',
          style: TextStyle(color: darkGreen, fontWeight: FontWeight.bold),
        ),
        backgroundColor: backgroundColor,
        foregroundColor: darkGreen,
        elevation: 0,
      ),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: primaryGreen),
            );
          }

          if (snapshot.hasError) {
            return buildErrorMessage(
              'Unable to load your profile. Please try again.',
            );
          }

          if (!snapshot.hasData || !snapshot.data!.exists) {
            return buildErrorMessage(
              'Complete your profile first to calculate your BMI and daily calories.',
            );
          }

          Map<String, dynamic> data = snapshot.data!.data() ?? {};

          double weight = (data['weight'] as num?)?.toDouble() ?? 0;
          double height = (data['height'] as num?)?.toDouble() ?? 0;
          int age = (data['age'] as num?)?.toInt() ?? 0;

          String gender = data['gender']?.toString() ?? 'Female';
          String healthGoal =
              data['healthGoal']?.toString() ?? 'Maintain Weight';

          double? targetWeight = (data['targetWeight'] as num?)?.toDouble();

          double weeklyWeightLoss =
              (data['weeklyWeightLoss'] as num?)?.toDouble() ?? 0.5;

          dynamic activityLevel = data['activityLevel'];

          if (weight <= 0 || height <= 0 || age <= 0) {
            return buildErrorMessage(
              'Please add your weight, height, and age in your profile.',
            );
          }

          bool needsTargetWeight =
              healthGoal == 'Lose Weight' || healthGoal == 'Gain Weight';

          if (needsTargetWeight &&
              (targetWeight == null || targetWeight <= 0)) {
            return buildErrorMessage(
              'Please set a valid target weight in your profile.',
            );
          }

          double bmi = calculateBmi(weight, height);
          double activityMultiplier = getActivityMultiplier(activityLevel);

          double calories = calculateCalories(
            weight: weight,
            height: height,
            age: age,
            gender: gender,
            activityMultiplier: activityMultiplier,
            healthGoal: healthGoal,
            targetWeight: targetWeight,
            weeklyWeightLoss: weeklyWeightLoss,
          );

          double heightM = height / 100;
          double healthyMinWeight = 18.5 * heightM * heightM;
          double healthyMaxWeight = 24.9 * heightM * heightM;

          return LayoutBuilder(
            builder: (context, screenConstraints) {
              double contentMaxWidth = screenConstraints.maxWidth >= 900
                  ? 850
                  : double.infinity;


              return SizedBox(
                width: double.infinity,
                height: screenConstraints.maxHeight,
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(20),
                  child: Center(
                    child: ConstrainedBox(
                      constraints: BoxConstraints(maxWidth: contentMaxWidth),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(22),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [darkGreen, primaryGreen],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(24),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Your Body Mass Index',
                                  style: TextStyle(
                                    color: Colors.white70,
                                    fontSize: 15,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Wrap(
                                  crossAxisAlignment: WrapCrossAlignment.center,
                                  spacing: 14,
                                  runSpacing: 8,
                                  children: [
                                    Text(
                                      bmi.toStringAsFixed(1),
                                      style: const TextStyle(
                                        fontSize: 42,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 12,
                                        vertical: 7,
                                      ),
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.18),
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Text(
                                        getBmiCategory(bmi),
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 14),
                                const Text(
                                  'BMI is a screening measure and does not directly measure body fat.',
                                  style: TextStyle(
                                    color: Colors.white70,
                                    fontSize: 13,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 24),

                          // BMI Range
                          buildSectionTitle('BMI Range'),
                          buildInfoCard(child: bmiRangeScale(bmi)),

                          const SizedBox(height: 24),


                          buildSectionTitle('Your Measurements'),
                          LayoutBuilder(
                            builder: (context, constraints) {
                              int columns = constraints.maxWidth >= 700
                                  ? 3
                                  : constraints.maxWidth >= 400
                                  ? 2
                                  : 1;

                              return GridView.count(
                                crossAxisCount: columns,
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                crossAxisSpacing: 12,
                                mainAxisSpacing: 12,
                                childAspectRatio: columns == 1 ? 2.2 : 1.15,
                                children: [
                                  measurementCard(
                                    icon: Icons.monitor_weight_outlined,
                                    label: 'Current Weight',
                                    value: '${weight.toStringAsFixed(1)} kg',
                                  ),
                                  measurementCard(
                                    icon: Icons.height,
                                    label: 'Height',
                                    value: '${height.toStringAsFixed(1)} cm',
                                  ),
                                  if (needsTargetWeight)
                                    measurementCard(
                                      icon: Icons.flag_outlined,
                                      label: 'Target Weight',
                                      value:
                                          '${targetWeight!.toStringAsFixed(1)} kg',
                                    ),
                                ],
                              );
                            },
                          ),

                          const SizedBox(height: 24),

                          // Daily Calories
                          buildSectionTitle('Daily Calorie Needs'),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(22),
                            decoration: BoxDecoration(
                              color: const Color(0xFFEAF4E9),
                              borderRadius: BorderRadius.circular(22),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Row(
                                  children: [
                                    Icon(
                                      Icons.local_fire_department,
                                      color: primaryGreen,
                                      size: 28,
                                    ),
                                    SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        'Estimated Daily Calories',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          color: darkGreen,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  '${calories.round()} kcal/day',
                                  style: const TextStyle(
                                    fontSize: 30,
                                    fontWeight: FontWeight.bold,
                                    color: darkGreen,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'Goal: $healthGoal',
                                  style: const TextStyle(
                                    fontSize: 14,
                                    color: mutedColor,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                const Text(
                                  'This is an estimate based on your profile, activity level, and selected goal.',
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: mutedColor,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 24),

                          // Healthy Weight Range
                          buildSectionTitle('Healthy Weight Range'),
                          buildInfoCard(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Estimated range based on the standard adult BMI range:',
                                  style: TextStyle(
                                    color: mutedColor,
                                    fontSize: 14,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  '${healthyMinWeight.toStringAsFixed(1)} – ${healthyMaxWeight.toStringAsFixed(1)} kg',
                                  style: const TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: darkGreen,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 24),

                          // BMI Insights
                          buildSectionTitle('Your BMI Insights'),
                          buildInfoCard(
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(
                                  Icons.lightbulb_outline,
                                  color: getBmiColor(bmi),
                                  size: 28,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    getBmiAdvice(bmi),
                                    style: const TextStyle(
                                      color: mutedColor,
                                      fontSize: 14,
                                      height: 1.6,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 20),

                          const Text(
                            'Note: BMI and calorie calculations are estimates, not medical advice. Individual needs vary. Consult a qualified healthcare professional for personalized guidance.',
                            style: TextStyle(
                              color: mutedColor,
                              fontSize: 12,
                              height: 1.5,
                            ),
                          ),

                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _BmiLegend extends StatelessWidget {
  final Color color;
  final String label;

  const _BmiLegend({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 5),
        Text(label, style: const TextStyle(fontSize: 11, color: mutedColor)),
      ],
    );
  }
}
