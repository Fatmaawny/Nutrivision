
import 'dart:convert';
import 'package:flutter/services.dart';

class FoodApiService {
  static const String _assetPath = 'assets/usda_foods.json';

  List<Map<String, dynamic>> _foods = [];
  List<String> _categories = [];

  bool _loaded = false;
  Future<void>? _loading;

  Future<void> initialize() {
    if (_loaded) return Future<void>.value();

    return _loading ??= _loadLocalData();
  }

  Future<void> _loadLocalData() async {
    try {
      final jsonString = await rootBundle.loadString(_assetPath);
      final decoded = jsonDecode(jsonString);

      if (decoded is! Map) {
        throw Exception('Invalid USDA JSON format.');
      }

      final rawFoods = decoded['foods'];
      final rawCategories = decoded['categories'];

      if (rawFoods is! List || rawCategories is! List) {
        throw Exception('USDA foods or categories are missing.');
      }

      _foods = rawFoods
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList();

      _categories = rawCategories
          .whereType<String>()
          .where((name) => name.trim().isNotEmpty)
          .toSet()
          .toList()
        ..sort();

      _loaded = true;

      print('USDA local foods: ${_foods.length}');
      print('USDA local categories: ${_categories.length}');
    } catch (e) {
      _loading = null;
      throw Exception('Could not load USDA data: $e');
    }
  }

  List<String> get categoryNames => List.unmodifiable(_categories);

  Future<List<Map<String, dynamic>>> getFoods({
    String query = '',
    int pageSize = 50,
  }) async {
    await initialize();

    final search = query.trim().toLowerCase();

    final results = _foods.where((food) {
      if (search.isEmpty) return true;

      final name = (food['description'] ?? '')
          .toString()
          .toLowerCase();

      final category = (food['category'] ?? '')
          .toString()
          .toLowerCase();

      return name.contains(search) || category.contains(search);
    }).take(pageSize);

    return results.map(_formatLocalFood).toList();
  }

  Future<List<Map<String, dynamic>>> getFoodsByCategory(
      String categoryKey, {
        int pageSize = 50,
        int maxPages = 1,
      }) async {
    await initialize();

    final matchingFoods = _foods.where((food) {
      final category = (food['category'] ?? '').toString();
      return category == categoryKey;
    });

    final limit = pageSize * maxPages;

    return matchingFoods
        .take(limit)
        .map(_formatLocalFood)
        .toList();
  }

  Future<Map<String, dynamic>> getFoodDetails(int fdcId) async {
    await initialize();

    Map<String, dynamic>? foundFood;

    for (final food in _foods) {
      if (food['fdcId'] == fdcId) {
        foundFood = food;
        break;
      }
    }

    if (foundFood == null) {
      throw Exception('Food not found in local USDA data.');
    }

    return _formatLocalFood(foundFood);
  }

  String _normalize(String value) {
    return value.trim().toLowerCase();
  }

  double? _number(dynamic value) {
    if (value is num) return value.toDouble();
    if (value is String) return double.tryParse(value);
    return null;
  }

  List<Map<String, dynamic>> _readNutrients(dynamic raw) {
    final result = <Map<String, dynamic>>[];

    // New JSON format preserves the nutrient name and unit.
    if (raw is List) {
      for (final item in raw) {
        if (item is! Map) continue;

        final name = (item['name'] ?? '').toString().trim();
        final unit = (item['unit'] ?? '').toString().trim();
        final amount = _number(item['amount']);

        if (name.isEmpty || amount == null) continue;

        result.add({
          'name': name,
          'unit': unit,
          'amount': amount,
        });
      }
    }

    // Compatibility with the older JSON format.
    if (raw is Map) {
      for (final entry in raw.entries) {
        final amount = _number(entry.value);

        if (amount == null) continue;

        result.add({
          'name': entry.key.toString(),
          'unit': '',
          'amount': amount,
        });
      }
    }

    return result;
  }

  double? _findNutrient(
      List<Map<String, dynamic>> nutrients,
      List<String> possibleNames, {
        String? preferredUnit,
      }) {
    final names = possibleNames.map(_normalize).toSet();

    final matches = nutrients.where((item) {
      return names.contains(_normalize(item['name'].toString()));
    }).toList();

    if (matches.isEmpty) return null;

    if (preferredUnit != null) {
      for (final item in matches) {
        if (_normalize(item['unit'].toString()) ==
            _normalize(preferredUnit)) {
          return _number(item['amount']);
        }
      }
    }

    return _number(matches.first['amount']);
  }

  double? _energyKcal(List<Map<String, dynamic>> nutrients) {
    final energyNames = ['energy'];

    // Prefer kcal so values are not accidentally displayed as kJ.
    final kcal = _findNutrient(
      nutrients,
      energyNames,
      preferredUnit: 'kcal',
    );

    if (kcal != null) return kcal;

    final kj = _findNutrient(
      nutrients,
      energyNames,
      preferredUnit: 'kJ',
    );

    if (kj != null) return kj / 4.184;

    return null;
  }

  Map<String, dynamic> _formatLocalFood(
      Map<String, dynamic> food,
      ) {
    final nutrients = _readNutrients(food['nutrients']);

    final category =
    (food['category'] ?? 'Uncategorized').toString();

    return {
      'fdcId': food['fdcId'],
      'name': food['description'] ?? 'Unknown food',
      'apiCategory': category,
      'category': category,

      'calories': _energyKcal(nutrients),

      'protein': _findNutrient(
        nutrients,
        ['protein'],
        preferredUnit: 'g',
      ),

      'carbs': _findNutrient(
        nutrients,
        [
          'carbohydrate, by difference',
          'carbohydrate, by summation',
          'carbohydrate',
        ],
        preferredUnit: 'g',
      ),

      'fat': _findNutrient(
        nutrients,
        ['total lipid (fat)', 'total fat'],
        preferredUnit: 'g',
      ),

      'fiber': _findNutrient(
        nutrients,
        ['fiber, total dietary'],
        preferredUnit: 'g',
      ),

      'sugar': _findNutrient(
        nutrients,
        [
          'sugars, total including nlea',
          'sugars, total',
        ],
        preferredUnit: 'g',
      ),

      'saturatedFat': _findNutrient(
        nutrients,
        ['fatty acids, total saturated'],
        preferredUnit: 'g',
      ),

      'sodium': _findNutrient(
        nutrients,
        ['sodium, na', 'sodium'],
        preferredUnit: 'mg',
      ),
    };
  }
}
