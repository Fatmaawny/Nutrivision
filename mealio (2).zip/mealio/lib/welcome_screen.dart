import 'package:flutter/material.dart';
import 'onboarding_screen.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  static const Color primaryGreen = Color(0xFF21865B);
  static const Color darkGreen = Color(0xFF145638);
  static const Color background = Color(0xFFFCFCF7);

  bool isLoading = false;

  Future<void> startApp() async {
    if (isLoading) return;

    setState(() {
      isLoading = true;
    });

    await Future.delayed(const Duration(seconds: 3));

    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const OnboardingScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final screenWidth = constraints.maxWidth;
            final screenHeight = constraints.maxHeight;

            final isWide = screenWidth >= 700;
            final isShort = screenHeight < 600;

            final logoSize = isWide
                ? 100.0
                : isShort
                ? 65.0
                : 80.0;

            final titleSize = isWide
                ? 40.0
                : isShort
                ? 27.0
                : 32.0;

            final subtitleSize = isWide
                ? 18.0
                : isShort
                ? 13.0
                : 15.0;

            final buttonWidth = isWide ? 280.0 : screenWidth * 0.65;

            final horizontalPadding = isWide ? 48.0 : 24.0;

            // Dynamic spacing based on screen height.
            final contentSpacing = (screenHeight * 0.035).clamp(12.0, 28.0);

            final topOffset = (screenHeight * 0.06).clamp(16.0, 45.0);

            return Stack(
              children: [
                // Decorative background.
                Positioned(
                  top: -20,
                  right: -35,
                  child: _buildLeafDecoration(isWide ? 180 : 120),
                ),

                Positioned(
                  bottom: 35,
                  left: -35,
                  child: Transform.rotate(
                    angle: 2.8,
                    child: _buildLeafDecoration(isWide ? 180 : 120),
                  ),
                ),

                Positioned(
                  bottom: 20,
                  right: 15,
                  child: Opacity(
                    opacity: 0.25,
                    child: _buildLeafDecoration(isWide ? 100 : 65),
                  ),
                ),

                // Responsive content.
                Center(
                  child: SingleChildScrollView(
                    padding: EdgeInsets.fromLTRB(
                      horizontalPadding,
                      topOffset,
                      horizontalPadding,
                      24,
                    ),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 650),
                      child: SizedBox(
                        width: double.infinity,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.eco,
                              size: logoSize,
                              color: primaryGreen,
                            ),

                            SizedBox(height: contentSpacing * 0.4),

                            Text(
                              'Mealio',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: titleSize,
                                fontWeight: FontWeight.bold,
                                color: darkGreen,
                              ),
                            ),

                            SizedBox(height: contentSpacing * 0.3),

                            Text(
                              'Eat Smart, Live Healthy.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: subtitleSize,
                                color: darkGreen,
                              ),
                            ),

                            SizedBox(height: contentSpacing * 1.5),

                            SizedBox(
                              width: buttonWidth,
                              height: isShort ? 46 : 52,
                              child: ElevatedButton(
                                onPressed: isLoading ? null : startApp,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: primaryGreen,
                                  foregroundColor: Colors.white,
                                  disabledBackgroundColor: primaryGreen
                                      .withOpacity(0.6),
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                ),
                                child: isLoading
                                    ? const SizedBox(
                                        width: 23,
                                        height: 23,
                                        child: CircularProgressIndicator(
                                          color: Colors.white,
                                          strokeWidth: 2.5,
                                        ),
                                      )
                                    : Text(
                                        "Let's Start",
                                        style: TextStyle(
                                          fontSize: isShort ? 14 : 16,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                              ),
                            ),

                            SizedBox(height: contentSpacing * 1.5),

                            Text(
                              'Your AI-powered\n'
                              'dietary health assistant',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: isWide
                                    ? 16
                                    : isShort
                                    ? 11
                                    : 12,
                                height: 1.5,
                                color: darkGreen,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildLeafDecoration(double size) {
    return Icon(Icons.eco, size: size, color: const Color(0xFFDDEACB));
  }
}
