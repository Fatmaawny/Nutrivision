import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

const Color primaryGreen = Color(0xFF105638);
const Color darkGreen = Color(0xFF0A3825);
const Color backgroundColor = Color(0xFFF2F4EC);
const Color lightGreen = Color(0xFFC5DCCB);
const Color headingColor = Color(0xFF19251D);
const Color mutedColor = Color(0xFF4F6054);
const Color borderColor = Color(0xFFC8D4C9);

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final User? user = FirebaseAuth.instance.currentUser;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final TextEditingController nameController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final TextEditingController heightController = TextEditingController();
  final TextEditingController weightController = TextEditingController();
  final TextEditingController targetWeightController = TextEditingController();
  final TextEditingController otherAllergyController = TextEditingController();

  bool isLoading = true;
  bool isSaving = false;
  bool isEditing = false;

  String gender = 'Female';
  String activityLevel = 'Sedentary';
  String healthGoal = 'Maintain Weight';
  String dietaryPreference = 'No Restrictions';
  String weeklyWeightLoss = '0.5';

  Set<String> selectedAllergies = {'None'};
  Map<String, dynamic> originalData = {};

  final List<String> genderOptions = ['Female', 'Male', 'Prefer not to say'];

  final List<String> activityOptions = [
    'Sedentary',
    'Lightly Active',
    'Moderately Active',
    'Very Active',
    'Extra Active',
  ];

  final List<String> healthGoalOptions = [
    'Lose Weight',
    'Maintain Weight',
    'Gain Weight',
    'Eat Healthier',
  ];

  final List<String> dietaryOptions = [
    'No Restrictions',
    'Vegetarian',
    'Vegan',
    'Pescatarian',
  ];

  final List<String> allergyOptions = [
    'None',
    'Milk',
    'Eggs',
    'Peanuts',
    'Tree Nuts',
    'Fish',
    'Shellfish',
    'Soy',
    'Wheat',
    'Sesame',
    'Other',
  ];

  final List<String> weeklyLossOptions = ['0.25', '0.5', '0.75', '1.0'];

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  @override
  void dispose() {
    nameController.dispose();
    ageController.dispose();
    heightController.dispose();
    weightController.dispose();
    targetWeightController.dispose();
    otherAllergyController.dispose();
    super.dispose();
  }

  String normalizeGender(dynamic value) {
    String result = value?.toString() ?? 'Female';

    if (result == 'Male' || result == 'ذكر') {
      return 'Male';
    }

    if (result == 'Prefer not to say') {
      return 'Prefer not to say';
    }

    return 'Female';
  }

  String normalizeChoice(
    dynamic value,
    List<String> options,
    String defaultValue,
  ) {
    String result = value?.toString() ?? defaultValue;
    return options.contains(result) ? result : defaultValue;
  }

  String normalizeWeeklyLoss(dynamic value) {
    String result = value?.toString() ?? '0.5';

    if (result == '1') {
      result = '1.0';
    }

    return weeklyLossOptions.contains(result) ? result : '0.5';
  }

  Future<void> loadProfile() async {
    if (user == null) {
      if (mounted) {
        setState(() => isLoading = false);
      }
      return;
    }

    try {
      DocumentSnapshot<Map<String, dynamic>> snapshot = await firestore
          .collection('users')
          .doc(user!.uid)
          .get();

      Map<String, dynamic> data = snapshot.data() ?? {};

      if (!mounted) return;

      setState(() {
        originalData = Map<String, dynamic>.from(data);
        populateFields(data);
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() => isLoading = false);
      showMessage('Failed to load profile: $e');
    }
  }

  void populateFields(Map<String, dynamic> data) {
    nameController.text =
        data['name']?.toString() ??
        data['fullName']?.toString() ??
        user?.displayName ??
        '';

    ageController.text = data['age']?.toString() ?? '';
    heightController.text = data['height']?.toString() ?? '';
    weightController.text = data['weight']?.toString() ?? '';

    targetWeightController.text = data['targetWeight']?.toString() ?? '';

    gender = normalizeGender(data['gender']);

    activityLevel = normalizeChoice(
      data['activityLevel'],
      activityOptions,
      'Sedentary',
    );

    healthGoal = normalizeChoice(
      data['healthGoal'],
      healthGoalOptions,
      'Maintain Weight',
    );

    dietaryPreference = normalizeChoice(
      data['dietaryPreference'],
      dietaryOptions,
      'No Restrictions',
    );

    weeklyWeightLoss = normalizeWeeklyLoss(data['weeklyWeightLoss']);

    selectedAllergies = {};
    otherAllergyController.clear();

    dynamic allergiesData = data['foodAllergies'];

    if (allergiesData is List) {
      for (dynamic allergy in allergiesData) {
        String value = allergy.toString();

        if (value.startsWith('Other: ')) {
          selectedAllergies.add('Other');
          otherAllergyController.text = value.substring('Other: '.length);
        } else if (value == 'Other') {
          selectedAllergies.add('Other');
        } else if (allergyOptions.contains(value)) {
          selectedAllergies.add(value);
        }
      }
    }

    if (selectedAllergies.isEmpty || selectedAllergies.contains('None')) {
      selectedAllergies = {'None'};
    }
  }

  void startEditing() {
    setState(() => isEditing = true);
  }

  void cancelEditing() {
    setState(() {
      populateFields(originalData);
      isEditing = false;
    });

    FocusScope.of(context).unfocus();
  }

  double? parseNumber(String value) {
    return double.tryParse(value.trim().replaceAll(',', '.'));
  }

  String? validateRequired(String? value, String fieldName) {
    if (value == null || value.trim().isEmpty) {
      return '$fieldName is required';
    }

    return null;
  }

  String? validatePositiveNumber(String? value, String fieldName) {
    if (value == null || value.trim().isEmpty) {
      return '$fieldName is required';
    }

    double? number = parseNumber(value);

    if (number == null || number <= 0) {
      return 'Enter a valid $fieldName';
    }

    return null;
  }

  Future<void> saveProfile() async {
    if (user == null) {
      showMessage('Please log in first.');
      return;
    }

    if (!formKey.currentState!.validate()) return;

    int? age = int.tryParse(ageController.text.trim());
    double? height = parseNumber(heightController.text);
    double? weight = parseNumber(weightController.text);
    double? targetWeight;

    if (healthGoal == 'Lose Weight' || healthGoal == 'Gain Weight') {
      targetWeight = parseNumber(targetWeightController.text);

      if (targetWeight == null || targetWeight <= 0) {
        showMessage('Please enter a valid target weight.');
        return;
      }

      if (weight == null || weight <= 0) {
        showMessage('Please enter a valid current weight.');
        return;
      }

      if (healthGoal == 'Lose Weight' && targetWeight >= weight) {
        showMessage(
          'For weight loss, the target weight must be lower than your current weight.',
        );
        return;
      }

      if (healthGoal == 'Gain Weight' && targetWeight <= weight) {
        showMessage(
          'For weight gain, the target weight must be higher than your current weight.',
        );
        return;
      }
    }

    if (age == null || age <= 0 || age > 120) {
      showMessage('Please enter a valid age.');
      return;
    }

    if (height == null || height <= 0 || weight == null || weight <= 0) {
      showMessage('Please check your height and weight.');
      return;
    }

    List<String> allergies = [];

    if (selectedAllergies.contains('None')) {
      allergies = ['None'];
    } else {
      allergies = selectedAllergies
          .where((item) => item != 'Other' && item != 'None')
          .toList();

      if (selectedAllergies.contains('Other')) {
        String otherAllergy = otherAllergyController.text.trim();

        if (otherAllergy.isEmpty) {
          showMessage('Please specify your other allergy.');
          return;
        }

        allergies.add('Other: $otherAllergy');
      }
    }

    setState(() => isSaving = true);

    try {
      Map<String, dynamic> savedFields = {
        'name': nameController.text.trim(),
        'age': age,
        'gender': gender,
        'height': height,
        'weight': weight,
        'activityLevel': activityLevel,
        'healthGoal': healthGoal,
        'targetWeight': targetWeight,
        'weeklyWeightLoss': healthGoal == 'Lose Weight'
            ? double.parse(weeklyWeightLoss)
            : null,
        'foodAllergies': allergies,
        'dietaryPreference': dietaryPreference,
      };

      Map<String, dynamic> firestoreData = {
        ...savedFields,
        'updatedAt': FieldValue.serverTimestamp(),
      };

      await firestore
          .collection('users')
          .doc(user!.uid)
          .set(firestoreData, SetOptions(merge: true));

      if (nameController.text.trim().isNotEmpty) {
        await user!.updateDisplayName(nameController.text.trim());
      }

      if (!mounted) return;

      setState(() {
        originalData = {...originalData, ...savedFields};
        isEditing = false;
        isSaving = false;
      });

      FocusScope.of(context).unfocus();
      showMessage('Profile updated successfully!');
    } catch (e) {
      if (!mounted) return;

      setState(() => isSaving = false);
      showMessage('Failed to save profile: $e');
    }
  }

  void toggleAllergy(String allergy, bool selected) {
    setState(() {
      if (allergy == 'None') {
        selectedAllergies = selected ? {'None'} : {};
        return;
      }

      selectedAllergies.remove('None');

      if (selected) {
        selectedAllergies.add(allergy);
      } else {
        selectedAllergies.remove(allergy);
      }

      if (selectedAllergies.isEmpty) {
        selectedAllergies = {'None'};
      }
    });
  }

  void showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: darkGreen,
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  String get allergyDisplayText {
    if (selectedAllergies.contains('None')) {
      return 'None';
    }

    List<String> items = selectedAllergies.toList();

    if (items.contains('Other')) {
      String other = otherAllergyController.text.trim();
      items.remove('Other');
      items.add(other.isNotEmpty ? other : 'Other');
    }

    return items.isEmpty ? 'None' : items.join(', ');
  }

  String get displayName {
    String name = nameController.text.trim();

    if (name.isNotEmpty) return name;

    return user?.email ?? 'User';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: backgroundColor,
        foregroundColor: headingColor,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'My Profile',
          style: TextStyle(fontWeight: FontWeight.bold, color: headingColor),
        ),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: primaryGreen))
          : user == null
          ? const Center(
              child: Text(
                'Please log in to view your profile.',
                style: TextStyle(color: mutedColor),
              ),
            )
          : SafeArea(
              child: Form(
                key: formKey,
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    double pageWidth = constraints.maxWidth;
                    double horizontalPadding = pageWidth >= 900 ? 40 : 20;

                    return ListView(
                      padding: EdgeInsets.symmetric(
                        horizontal: horizontalPadding,
                        vertical: 20,
                      ),
                      children: [
                        Center(
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 1100),
                            child: Column(
                              children: [
                                buildProfileHeader(),
                                const SizedBox(height: 24),

                                buildSection(
                                  title: 'Personal Information',
                                  icon: Icons.person_outline,
                                  children: [
                                    responsiveGrid([
                                      buildTextField(
                                        label: 'Full Name',
                                        controller: nameController,
                                        icon: Icons.badge_outlined,
                                        validator: (value) =>
                                            validateRequired(value, 'Name'),
                                      ),
                                      buildTextField(
                                        label: 'Email Address',
                                        initialValue: user!.email ?? '',
                                        icon: Icons.email_outlined,
                                        enabled: false,
                                        keyboardType:
                                            TextInputType.emailAddress,
                                      ),
                                      buildTextField(
                                        label: 'Age',
                                        controller: ageController,
                                        icon: Icons.cake_outlined,
                                        keyboardType: TextInputType.number,
                                        validator: (value) {
                                          String? result = validateRequired(
                                            value,
                                            'Age',
                                          );

                                          if (result != null) {
                                            return result;
                                          }

                                          int? number = int.tryParse(
                                            value!.trim(),
                                          );

                                          if (number == null ||
                                              number <= 0 ||
                                              number > 120) {
                                            return 'Enter a valid age';
                                          }

                                          return null;
                                        },
                                      ),
                                      buildDropdown(
                                        label: 'Gender',
                                        value: gender,
                                        options: genderOptions,
                                        icon: Icons.wc_outlined,
                                        onChanged: (value) {
                                          setState(() {
                                            gender = value!;
                                          });
                                        },
                                      ),
                                    ]),
                                  ],
                                ),

                                const SizedBox(height: 18),

                                buildSection(
                                  title: 'Body Information',
                                  icon: Icons.monitor_weight_outlined,
                                  children: [
                                    responsiveGrid([
                                      buildTextField(
                                        label: 'Height (cm)',
                                        controller: heightController,
                                        icon: Icons.height,
                                        keyboardType:
                                            const TextInputType.numberWithOptions(
                                              decimal: true,
                                            ),
                                        validator: (value) =>
                                            validatePositiveNumber(
                                              value,
                                              'height',
                                            ),
                                      ),
                                      buildTextField(
                                        label: 'Weight (kg)',
                                        controller: weightController,
                                        icon: Icons.monitor_weight_outlined,
                                        keyboardType:
                                            const TextInputType.numberWithOptions(
                                              decimal: true,
                                            ),
                                        validator: (value) =>
                                            validatePositiveNumber(
                                              value,
                                              'weight',
                                            ),
                                      ),
                                      buildDropdown(
                                        label: 'Activity Level',
                                        value: activityLevel,
                                        options: activityOptions,
                                        icon: Icons.directions_walk_outlined,
                                        onChanged: (value) {
                                          setState(() {
                                            activityLevel = value!;
                                          });
                                        },
                                      ),
                                    ]),
                                  ],
                                ),

                                const SizedBox(height: 18),

                                buildSection(
                                  title: 'Health Goals',
                                  icon: Icons.flag_outlined,
                                  children: [
                                    responsiveGrid([
                                      buildDropdown(
                                        label: 'Health Goal',
                                        value: healthGoal,
                                        options: healthGoalOptions,
                                        icon: Icons.track_changes_outlined,
                                        onChanged: (value) {
                                          setState(() {
                                            healthGoal = value!;
                                          });
                                        },
                                      ),
                                      if (healthGoal == 'Lose Weight' ||
                                          healthGoal == 'Gain Weight')
                                        buildTextField(
                                          label: 'Target Weight (kg)',
                                          controller: targetWeightController,
                                          icon: Icons.monitor_weight_outlined,
                                          keyboardType:
                                              const TextInputType.numberWithOptions(
                                                decimal: true,
                                              ),
                                          validator: (value) {
                                            if (healthGoal != 'Lose Weight' &&
                                                healthGoal != 'Gain Weight') {
                                              return null;
                                            }

                                            return validatePositiveNumber(
                                              value,
                                              'target weight',
                                            );
                                          },
                                        ),
                                      if (healthGoal == 'Lose Weight')
                                        buildDropdown(
                                          label: 'Weekly Weight Loss (kg)',
                                          value: weeklyWeightLoss,
                                          options: weeklyLossOptions,
                                          icon: Icons.trending_down,
                                          onChanged: (value) {
                                            setState(() {
                                              weeklyWeightLoss = value!;
                                            });
                                          },
                                        ),
                                    ]),
                                  ],
                                ),

                                const SizedBox(height: 18),

                                buildSection(
                                  title: 'Dietary Preferences',
                                  icon: Icons.restaurant_outlined,
                                  children: [
                                    responsiveGrid([
                                      buildDropdown(
                                        label: 'Dietary Preference',
                                        value: dietaryPreference,
                                        options: dietaryOptions,
                                        icon: Icons.eco_outlined,
                                        onChanged: (value) {
                                          setState(() {
                                            dietaryPreference = value!;
                                          });
                                        },
                                      ),
                                    ]),
                                    const SizedBox(height: 8),
                                    const Text(
                                      'Food Allergies',
                                      style: TextStyle(
                                        color: headingColor,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    if (isEditing)
                                      Wrap(
                                        spacing: 8,
                                        runSpacing: 8,
                                        children: allergyOptions.map((allergy) {
                                          bool selected = selectedAllergies
                                              .contains(allergy);

                                          return FilterChip(
                                            label: Text(allergy),
                                            selected: selected,
                                            onSelected: (value) {
                                              toggleAllergy(allergy, value);
                                            },
                                            selectedColor: lightGreen,
                                            checkmarkColor: primaryGreen,
                                            backgroundColor: Colors.white,
                                            side: BorderSide(
                                              color: selected
                                                  ? primaryGreen
                                                  : borderColor,
                                            ),
                                            labelStyle: TextStyle(
                                              color: selected
                                                  ? darkGreen
                                                  : mutedColor,
                                              fontSize: 13,
                                            ),
                                          );
                                        }).toList(),
                                      )
                                    else
                                      buildReadOnlyValue(
                                        allergyDisplayText,
                                        Icons.health_and_safety_outlined,
                                      ),
                                    if (isEditing &&
                                        selectedAllergies.contains(
                                          'Other',
                                        )) ...[
                                      const SizedBox(height: 12),
                                      buildTextField(
                                        label: 'Specify Other Allergy',
                                        controller: otherAllergyController,
                                        icon: Icons.edit_outlined,
                                      ),
                                    ],
                                    if (isEditing &&
                                        !selectedAllergies.contains(
                                          'None',
                                        )) ...[
                                      const SizedBox(height: 8),
                                      const Text(
                                        'Select all allergies that apply.',
                                        style: TextStyle(
                                          color: mutedColor,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ],
                                ),

                                const SizedBox(height: 20),

                                // Smaller Cancel and Save buttons.
                                if (isEditing)
                                  Row(
                                    children: [
                                      Expanded(
                                        child: OutlinedButton(
                                          onPressed: isSaving
                                              ? null
                                              : cancelEditing,
                                          style: OutlinedButton.styleFrom(
                                            foregroundColor: darkGreen,
                                            side: const BorderSide(
                                              color: primaryGreen,
                                            ),
                                            minimumSize: const Size(0, 44),
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 12,
                                              vertical: 10,
                                            ),
                                            tapTargetSize: MaterialTapTargetSize
                                                .shrinkWrap,
                                            visualDensity:
                                                VisualDensity.compact,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                          ),
                                          child: const Text(
                                            'Cancel',
                                            style: TextStyle(
                                              fontSize: 13,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: ElevatedButton(
                                          onPressed: isSaving
                                              ? null
                                              : saveProfile,
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: primaryGreen,
                                            foregroundColor: Colors.white,
                                            minimumSize: const Size(0, 44),
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 12,
                                              vertical: 10,
                                            ),
                                            tapTargetSize: MaterialTapTargetSize
                                                .shrinkWrap,
                                            visualDensity:
                                                VisualDensity.compact,
                                            elevation: 0,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                          ),
                                          child: isSaving
                                              ? const SizedBox(
                                                  height: 17,
                                                  width: 17,
                                                  child:
                                                      CircularProgressIndicator(
                                                        strokeWidth: 2,
                                                        color: Colors.white,
                                                      ),
                                                )
                                              : const Text(
                                                  'Save Changes',
                                                  style: TextStyle(
                                                    fontSize: 13,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                        ),
                                      ),
                                    ],
                                  )
                                else
                                  SizedBox(
                                    width: double.infinity,
                                    child: ElevatedButton.icon(
                                      onPressed: startEditing,
                                      icon: const Icon(
                                        Icons.edit_outlined,
                                        size: 18,
                                      ),
                                      label: const Text(
                                        'Edit Profile',
                                        style: TextStyle(fontSize: 14),
                                      ),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: primaryGreen,
                                        foregroundColor: Colors.white,
                                        minimumSize: const Size(0, 46),
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 16,
                                          vertical: 12,
                                        ),
                                        elevation: 0,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                            12,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),

                                const SizedBox(height: 24),
                              ],
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ),
    );
  }

  // Responsive Grid:
  // Small screens: 1 column
  // Medium screens: 2 columns
  // Large screens: 3 columns
  Widget responsiveGrid(List<Widget> children) {
    return LayoutBuilder(
      builder: (context, constraints) {
        int columns;

        if (constraints.maxWidth >= 950) {
          columns = 3;
        } else if (constraints.maxWidth >= 560) {
          columns = 2;
        } else {
          columns = 1;
        }

        return GridView.count(
          crossAxisCount: columns,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 14,
          mainAxisSpacing: 0,
          mainAxisExtent: 94,
          children: children,
        );
      },
    );
  }

  Widget buildProfileHeader() {
    String firstLetter = displayName.isNotEmpty
        ? displayName[0].toUpperCase()
        : 'U';

    return Container(
      width: double.infinity,
      constraints: const BoxConstraints(maxWidth: 700),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderColor),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            top: -45,
            right: -35,
            child: Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                color: lightGreen.withValues(alpha: 0.9),
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            top: 30,
            left: -45,
            child: Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: lightGreen.withValues(alpha: 0.65),
                shape: BoxShape.circle,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: primaryGreen.withValues(alpha: 0.35),
                      width: 2,
                    ),
                  ),
                  child: CircleAvatar(
                    radius: 42,
                    backgroundColor: lightGreen,
                    child: Text(
                      firstLetter,
                      style: const TextStyle(
                        color: darkGreen,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  displayName,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: headingColor,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  user?.email ?? '',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: mutedColor, fontSize: 13),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 7,
                  ),
                  decoration: BoxDecoration(
                    color: lightGreen,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Text(
                    'Mealio Member',
                    style: TextStyle(
                      color: darkGreen,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildSection({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: lightGreen,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: primaryGreen, size: 21),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color: headingColor,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          ...children,
        ],
      ),
    );
  }

  Widget buildTextField({
    required String label,
    TextEditingController? controller,
    String? initialValue,
    required IconData icon,
    bool enabled = true,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextFormField(
        controller: controller,
        initialValue: controller == null ? initialValue : null,
        enabled: isEditing && enabled,
        keyboardType: keyboardType,
        validator: validator,
        style: const TextStyle(color: headingColor, fontSize: 14),
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, color: mutedColor, size: 20),
          labelStyle: const TextStyle(color: mutedColor, fontSize: 13),
          filled: true,
          fillColor: isEditing && enabled
              ? backgroundColor
              : const Color(0xFFF8F9F6),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 15,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: borderColor),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: borderColor),
          ),
          disabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: borderColor),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: primaryGreen, width: 1.5),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: Colors.redAccent),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: Colors.redAccent, width: 1.5),
          ),
        ),
      ),
    );
  }

  Widget buildDropdown({
    required String label,
    required String value,
    required List<String> options,
    required IconData icon,
    required ValueChanged<String?> onChanged,
  }) {
    String safeValue = options.contains(value) ? value : options.first;

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: DropdownButtonFormField<String>(
        initialValue: safeValue,
        isExpanded: true,
        dropdownColor: const Color(0xFFE8F3EC),
        borderRadius: BorderRadius.circular(12),
        icon: const Icon(Icons.keyboard_arrow_down_rounded, color: mutedColor),
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, color: mutedColor, size: 20),
          labelStyle: const TextStyle(color: mutedColor, fontSize: 13),
          filled: true,
          fillColor: isEditing ? backgroundColor : const Color(0xFFF8F9F6),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 15,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: borderColor),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: borderColor),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: primaryGreen, width: 1.5),
          ),
        ),
        items: options.map((option) {
          return DropdownMenuItem<String>(
            value: option,
            child: Text(
              option,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: headingColor, fontSize: 14),
            ),
          );
        }).toList(),
        onChanged: isEditing ? onChanged : null,
      ),
    );
  }

  Widget buildReadOnlyValue(String value, IconData icon) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F9F6),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: borderColor),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: mutedColor, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(color: headingColor, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }
}
