import 'package:flutter/material.dart';
import 'food_api.dart';
import 'meal_data_service.dart';

const Color primaryGreen = Color(0xFF41644A);
const Color backgroundColor = Color(0xFFF7F8F2);
const Color headingColor = Color(0xFF26382B);
const Color lightGreen = Color(0xFFE5EEDD);
const Color secondaryGreen = Color(0xFF526653);
const Color borderColor = Color(0xFFDCE5D9);

class MealsScreen extends StatefulWidget {
  const MealsScreen({super.key});

  @override
  State<MealsScreen> createState() => _MealsScreenState();
}

class _MealsScreenState extends State<MealsScreen> {
  final FoodApiService foodApi = FoodApiService();
  final MealDataService mealService = MealDataService();

  final TextEditingController searchController = TextEditingController();

  final Map<String, TextEditingController> quantityControllers = {};

  final List<String> mealTypes = ['Breakfast', 'Lunch', 'Dinner', 'Snack'];

  final List<String> tabNames = ['Ingredients', 'Custom Meal'];

  final List<IconData> tabIcons = [
    Icons.restaurant_menu,
    Icons.add_circle_outline,
  ];

  List<String> get categories => ['All', ...foodApi.categoryNames];

  List<Map<String, dynamic>> foods = [];
  List<Map<String, dynamic>> savedMeals = [];
  List<Map<String, dynamic>> customIngredients = [];

  final Set<String> loadingFoodIds = {};

  String selectedCategory = 'All';
  String selectedMealType = 'Breakfast';
  String currentQuery = '';

  int selectedTab = 0;
  int _foodRequestId = 0;

  // Show only 30 food cards initially to reduce UI lag.
  int displayedFoodsCount = 30;

  bool isLoading = true;
  bool isLoadingMore = false;
  bool isSaving = false;
  bool isInitializing = true;

  String? errorMessage;

  @override
  void initState() {
    super.initState();
    initializeFoodData();
    loadSavedMeals();
  }

  Future<void> initializeFoodData() async {
    final stopwatch = Stopwatch()..start();

    try {
      debugPrint('Starting food initialization');

      await foodApi.initialize();

      debugPrint('Food data initialized: ${stopwatch.elapsedMilliseconds} ms');

      if (!mounted) return;

      await loadFoods(query: '');
    } catch (e, stackTrace) {
      debugPrint('Error initializing food data: $e');
      debugPrintStack(stackTrace: stackTrace);

      if (!mounted) return;

      setState(() {
        isInitializing = false;
        isLoading = false;
        foods = [];
        errorMessage =
            'Could not load USDA food data. Check assets/usda_foods.json.';
      });
    } finally {
      stopwatch.stop();

      if (mounted) {
        setState(() {
          isInitializing = false;
        });
      }
    }
  }

  @override
  void dispose() {
    searchController.dispose();

    for (final controller in quantityControllers.values) {
      controller.dispose();
    }

    super.dispose();
  }

  double toDouble(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse(value?.toString() ?? '') ?? 0.0;
  }

  double? nutrientValue(Map<String, dynamic> food, String key) {
    final value = food[key];

    if (value is num) return value.toDouble();
    if (value is String) return double.tryParse(value);

    return null;
  }

  String formatValue(dynamic value, {int decimals = 1}) {
    if (value is! num) return 'N/A';
    return value.toStringAsFixed(decimals);
  }

  String foodKey(Map<String, dynamic> food) {
    return food['fdcId']?.toString() ?? food['name']?.toString() ?? 'unknown';
  }

  TextEditingController quantityControllerFor(Map<String, dynamic> food) {
    final key = foodKey(food);

    if (!quantityControllers.containsKey(key)) {
      quantityControllers[key] = TextEditingController(text: '100');
    }

    return quantityControllers[key]!;
  }

  Future<void> loadFoods({required String query}) async {
    if (!mounted) return;

    final requestId = ++_foodRequestId;
    final requestedCategory = selectedCategory;
    final normalizedQuery = query.trim();

    setState(() {
      isLoading = true;
      errorMessage = null;
      currentQuery = normalizedQuery;
      displayedFoodsCount = 30;
    });

    try {
      List<Map<String, dynamic>> result = [];

      if (requestedCategory == 'All') {
        result = await foodApi.getFoods(query: normalizedQuery, pageSize: 500);
      } else {
        result = await foodApi.getFoodsByCategory(
          requestedCategory,
          pageSize: 500,
          maxPages: 1,
        );

        if (normalizedQuery.isNotEmpty) {
          final search = normalizedQuery.toLowerCase();

          result = result.where((food) {
            final name = (food['name'] ?? '').toString().toLowerCase();

            final category = (food['category'] ?? food['apiCategory'] ?? '')
                .toString()
                .toLowerCase();

            return name.contains(search) || category.contains(search);
          }).toList();
        }
      }

      debugPrint('Selected category: $requestedCategory');
      debugPrint('Search query: $normalizedQuery');
      debugPrint('Foods returned: ${result.length}');

      if (!mounted || requestId != _foodRequestId) return;

      setState(() {
        foods = result;
        isLoading = false;
        errorMessage = null;
      });
    } catch (e, stackTrace) {
      debugPrint('Could not load foods: $e');
      debugPrintStack(stackTrace: stackTrace);

      if (!mounted || requestId != _foodRequestId) return;

      setState(() {
        foods = [];
        isLoading = false;
        errorMessage = 'Could not load foods. Please try again.';
      });
    }
  }

  Future<void> loadSavedMeals() async {
    try {
      final result = await mealService.getMeals();

      if (!mounted) return;

      setState(() {
        savedMeals = result;
      });
    } catch (e) {
      debugPrint('Could not load saved meals: $e');

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Could not load saved meals. Please log in again.'),
        ),
      );
    }
  }

  void searchFoods() {
    final query = searchController.text.trim();

    setState(() {
      selectedCategory = 'All';
    });

    loadFoods(query: query);
  }

  void selectCategory(String category) {
    setState(() {
      selectedCategory = category;
    });

    loadFoods(query: searchController.text.trim());
  }

  List<Map<String, dynamic>> get visibleFoods => foods;

  double getMealCalories(String mealType) {
    double total = 0;

    for (final meal in savedMeals) {
      if (meal['mealType']?.toString() == mealType) {
        total += toDouble(meal['calories']);
      }
    }

    return total;
  }

  bool hasRequiredNutrients(Map<String, dynamic> food) {
    return nutrientValue(food, 'calories') != null &&
        nutrientValue(food, 'protein') != null &&
        nutrientValue(food, 'carbs') != null &&
        nutrientValue(food, 'fat') != null;
  }

  Future<void> addToCustomMeal(Map<String, dynamic> food) async {
    final key = foodKey(food);

    final existingIndex = customIngredients.indexWhere(
      (item) => foodKey(item) == key,
    );

    if (existingIndex != -1) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('This ingredient is already in your meal.'),
        ),
      );
      return;
    }

    final controller = quantityControllerFor(food);
    final grams = double.tryParse(controller.text.trim());

    if (grams == null || !grams.isFinite || grams <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a valid quantity in grams.')),
      );
      return;
    }

    setState(() {
      loadingFoodIds.add(key);
    });

    try {
      Map<String, dynamic> selectedFood = Map<String, dynamic>.from(food);
      final id = food['fdcId'];

      if (id is num) {
        final details = await foodApi.getFoodDetails(id.toInt());

        selectedFood = {...food, ...details};
      }

      if (!mounted) return;

      final alreadyAdded = customIngredients.any(
        (item) => foodKey(item) == key,
      );

      if (alreadyAdded) return;

      setState(() {
        customIngredients.add({...selectedFood, 'grams': grams});
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${selectedFood['name']} added to Custom Meal'),
          backgroundColor: primaryGreen,
        ),
      );
    } catch (e, stackTrace) {
      debugPrint('Could not load food details: $e');
      debugPrintStack(stackTrace: stackTrace);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Could not load complete food details. Please try again.',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          loadingFoodIds.remove(key);
        });
      }
    }
  }

  void changeIngredientQuantity(int index, String value) {
    final grams = double.tryParse(value);

    if (grams == null || !grams.isFinite || grams <= 0) return;

    setState(() {
      customIngredients[index]['grams'] = grams;
    });
  }

  void removeCustomIngredient(int index) {
    setState(() {
      customIngredients.removeAt(index);
    });
  }

  double? customTotal(String nutrient) {
    double total = 0;

    for (final food in customIngredients) {
      final value = nutrientValue(food, nutrient);

      if (value == null) return null;

      final grams = toDouble(food['grams']);
      total += value * grams / 100;
    }

    return total;
  }

  double get customTotalGrams {
    double total = 0;

    for (final food in customIngredients) {
      total += toDouble(food['grams']);
    }

    return total;
  }

  Future<void> saveCustomMeal() async {
    if (isSaving) return;

    if (customIngredients.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Add at least one ingredient first.')),
      );
      return;
    }

    final incompleteFoods = customIngredients
        .where((food) => !hasRequiredNutrients(food))
        .toList();

    if (incompleteFoods.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Some ingredients are missing calories or macros. '
            'Remove them or choose another USDA food record.',
          ),
        ),
      );
      return;
    }

    final calories = customTotal('calories');
    final protein = customTotal('protein');
    final carbs = customTotal('carbs');
    final fat = customTotal('fat');

    if (calories == null || protein == null || carbs == null || fat == null) {
      return;
    }

    setState(() {
      isSaving = true;
    });

    try {
      final components = customIngredients.map((food) {
        final grams = toDouble(food['grams']);

        return <String, dynamic>{
          'foodName': food['name']?.toString() ?? 'Unknown food',
          'fdcId': food['fdcId'],
          'grams': grams,
          'calories': toDouble(food['calories']) * grams / 100,
          'protein': toDouble(food['protein']) * grams / 100,
          'carbs': toDouble(food['carbs']) * grams / 100,
          'fat': toDouble(food['fat']) * grams / 100,
          'fiber': nutrientValue(food, 'fiber') == null
              ? null
              : toDouble(food['fiber']) * grams / 100,
          'sugar': nutrientValue(food, 'sugar') == null
              ? null
              : toDouble(food['sugar']) * grams / 100,
          'saturatedFat': nutrientValue(food, 'saturatedFat') == null
              ? null
              : toDouble(food['saturatedFat']) * grams / 100,
          'sodium': nutrientValue(food, 'sodium') == null
              ? null
              : toDouble(food['sodium']) * grams / 100,
        };
      }).toList();

      await mealService.addCustomMeal(
        foodName: selectedMealType,
        mealType: selectedMealType,
        components: components,
        grams: customTotalGrams,
        calories: calories,
        protein: protein,
        carbs: carbs,
        fat: fat,
      );

      await loadSavedMeals();

      if (!mounted) return;

      setState(() {
        customIngredients.clear();
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Custom meal saved successfully!'),
          backgroundColor: primaryGreen,
        ),
      );
    } catch (e) {
      debugPrint('Could not save custom meal: $e');

      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Could not save meal: $e')));
    } finally {
      if (mounted) {
        setState(() {
          isSaving = false;
        });
      }
    }
  }

  Future<void> deleteMeal(String mealId) async {
    try {
      await mealService.deleteMeal(mealId);
      await loadSavedMeals();

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Meal deleted.'),
          backgroundColor: primaryGreen,
        ),
      );
    } catch (e) {
      debugPrint('Could not delete meal: $e');

      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Could not delete meal.')));
    }
  }

  Widget sectionTitle(String title, {IconData? icon, double fontSize = 20}) {
    return Row(
      children: [
        if (icon != null) ...[
          Icon(icon, color: primaryGreen, size: 23),
          const SizedBox(width: 9),
        ],
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              color: headingColor,
            ),
          ),
        ),
      ],
    );
  }

  Widget _mealCaloriesCard(
    String title,
    double calories,
    IconData icon,
    Color accentColor,
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor),
      ),
      child: Stack(
        children: [
          Positioned(
            right: -5,
            bottom: -8,
            child: Icon(icon, size: 62, color: accentColor.withOpacity(0.08)),
          ),
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: accentColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: accentColor, size: 21),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: secondaryGreen,
                      ),
                    ),
                    const SizedBox(height: 4),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(
                        '${calories.round()} kcal',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: headingColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _macroText(String title, dynamic value) {
    return Text(
      '$title: ${formatValue(value)} g',
      style: const TextStyle(fontSize: 12, color: secondaryGreen),
    );
  }

  Widget _nutrientChip(String title, dynamic value, String unit) {
    final formatted = value is num
        ? '${value.toStringAsFixed(1)} $unit'
        : 'N/A';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: borderColor),
      ),
      child: Text(
        '$title: $formatted',
        style: const TextStyle(fontSize: 11, color: secondaryGreen),
      ),
    );
  }

  Widget buildFoodCard(Map<String, dynamic> food) {
    final controller = quantityControllerFor(food);
    final key = foodKey(food);

    final name = food['name']?.toString() ?? 'Unknown food';

    final category = food['category']?.toString().trim().isNotEmpty == true
        ? food['category'].toString()
        : food['apiCategory']?.toString().trim() ?? '';

    final calories = nutrientValue(food, 'calories');
    final protein = nutrientValue(food, 'protein');
    final carbs = nutrientValue(food, 'carbs');
    final fat = nutrientValue(food, 'fat');
    final fiber = nutrientValue(food, 'fiber');
    final sugar = nutrientValue(food, 'sugar');
    final saturatedFat = nutrientValue(food, 'saturatedFat');
    final sodium = nutrientValue(food, 'sodium');

    final isAdding = loadingFoodIds.contains(key);

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 48,
                width: 48,
                decoration: BoxDecoration(
                  color: lightGreen,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: const Icon(
                  Icons.restaurant_menu,
                  color: primaryGreen,
                  size: 25,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: headingColor,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      category.isEmpty ? 'Uncategorized' : category,
                      style: const TextStyle(
                        color: secondaryGreen,
                        fontSize: 11,
                      ),
                    ),
                    if (food['fdcId'] != null) ...[
                      const SizedBox(height: 3),
                      Text(
                        'USDA FDC ID: ${food['fdcId']}',
                        style: const TextStyle(
                          color: secondaryGreen,
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: lightGreen,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${formatValue(calories)} kcal / 100 g',
                  style: const TextStyle(
                    color: primaryGreen,
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _nutrientChip('Protein', protein, 'g'),
                    _nutrientChip('Carbs', carbs, 'g'),
                    _nutrientChip('Fat', fat, 'g'),
                    _nutrientChip('Fiber', fiber, 'g'),
                    _nutrientChip('Sugar', sugar, 'g'),
                    _nutrientChip('Saturated fat', saturatedFat, 'g'),
                    _nutrientChip('Sodium', sodium, 'mg'),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controller,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  decoration: InputDecoration(
                    labelText: 'Quantity (g)',
                    filled: true,
                    fillColor: backgroundColor,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 12,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13),
                      borderSide: const BorderSide(color: borderColor),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                tooltip: 'Add to Custom Meal',
                onPressed: isAdding ? null : () => addToCustomMeal(food),
                icon: isAdding
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: primaryGreen,
                        ),
                      )
                    : const Icon(Icons.playlist_add),
                color: primaryGreen,
                style: IconButton.styleFrom(
                  backgroundColor: lightGreen,
                  minimumSize: const Size(48, 48),
                ),
              ),
            ],
          ),
          const SizedBox(height: 5),
          const Text(
            'Nutritional values are shown per 100 g when available.',
            style: TextStyle(color: secondaryGreen, fontSize: 10),
          ),
        ],
      ),
    );
  }

  Widget buildCustomIngredientCard(Map<String, dynamic> food, int index) {
    final grams = toDouble(food['grams']);
    final calories = nutrientValue(food, 'calories');
    final factor = grams / 100;

    final scaledCalories = calories == null ? null : calories * factor;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.eco_outlined, color: primaryGreen),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  food['name']?.toString() ?? 'Ingredient',
                  style: const TextStyle(
                    color: headingColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              IconButton(
                onPressed: () => removeCustomIngredient(index),
                icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
              ),
            ],
          ),
          Row(
            children: [
              SizedBox(
                width: 105,
                child: TextFormField(
                  key: ValueKey('${foodKey(food)}_${grams.toString()}'),
                  initialValue: grams.toStringAsFixed(0),
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  decoration: InputDecoration(
                    labelText: 'Grams',
                    isDense: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onChanged: (value) {
                    changeIngredientQuantity(index, value);
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  scaledCalories == null
                      ? 'Calories: N/A'
                      : '${scaledCalories.toStringAsFixed(1)} kcal',
                  style: const TextStyle(
                    color: primaryGreen,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _nutrientChip(
                'Protein',
                nutrientValue(food, 'protein') == null
                    ? null
                    : toDouble(food['protein']) * factor,
                'g',
              ),
              _nutrientChip(
                'Carbs',
                nutrientValue(food, 'carbs') == null
                    ? null
                    : toDouble(food['carbs']) * factor,
                'g',
              ),
              _nutrientChip(
                'Fat',
                nutrientValue(food, 'fat') == null
                    ? null
                    : toDouble(food['fat']) * factor,
                'g',
              ),
              _nutrientChip(
                'Fiber',
                nutrientValue(food, 'fiber') == null
                    ? null
                    : toDouble(food['fiber']) * factor,
                'g',
              ),
              _nutrientChip(
                'Sugar',
                nutrientValue(food, 'sugar') == null
                    ? null
                    : toDouble(food['sugar']) * factor,
                'g',
              ),
              _nutrientChip(
                'Saturated fat',
                nutrientValue(food, 'saturatedFat') == null
                    ? null
                    : toDouble(food['saturatedFat']) * factor,
                'g',
              ),
              _nutrientChip(
                'Sodium',
                nutrientValue(food, 'sodium') == null
                    ? null
                    : toDouble(food['sodium']) * factor,
                'mg',
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget buildCustomMealTabBody() {
    final calories = customTotal('calories');
    final protein = customTotal('protein');
    final carbs = customTotal('carbs');
    final fat = customTotal('fat');

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        sectionTitle('Create your own meal', icon: Icons.add_circle_outline),
        const SizedBox(height: 7),
        const Text(
          'Add ingredients from the Ingredients tab, then set their quantities here.',
          style: TextStyle(color: secondaryGreen, fontSize: 13),
        ),
        const SizedBox(height: 18),
        const Text(
          'Meal Type',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: headingColor,
          ),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: mealTypes.map((type) {
            final isSelected = selectedMealType == type;

            return ChoiceChip(
              label: Text(type),
              selected: isSelected,
              showCheckmark: false,
              selectedColor: primaryGreen,
              backgroundColor: lightGreen,
              side: BorderSide(color: isSelected ? primaryGreen : borderColor),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              labelStyle: TextStyle(
                color: isSelected ? Colors.white : headingColor,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
              onSelected: (_) {
                setState(() {
                  selectedMealType = type;
                });
              },
            );
          }).toList(),
        ),
        const SizedBox(height: 18),
        if (customIngredients.isEmpty)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(25),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: borderColor),
            ),
            child: const Column(
              children: [
                Icon(Icons.no_meals_outlined, size: 40, color: primaryGreen),
                SizedBox(height: 10),
                Text(
                  'No ingredients added yet',
                  style: TextStyle(
                    color: headingColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  'Go to Ingredients and tap the list icon on a food.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: secondaryGreen, fontSize: 12),
                ),
              ],
            ),
          )
        else ...[
          ...List.generate(
            customIngredients.length,
            (index) =>
                buildCustomIngredientCard(customIngredients[index], index),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: lightGreen,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Nutrition summary',
                  style: TextStyle(
                    color: headingColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Total quantity: ${customTotalGrams.toStringAsFixed(0)} g',
                ),
                const SizedBox(height: 8),
                Text(
                  'Calories: ${calories == null ? 'N/A' : '${calories.toStringAsFixed(1)} kcal'}',
                ),
                const SizedBox(height: 8),
                _macroText('Protein', protein),
                const SizedBox(height: 6),
                _macroText('Carbs', carbs),
                const SizedBox(height: 6),
                _macroText('Fat', fat),
                const SizedBox(height: 10),
                const Text(
                  'N/A means the nutrient was not available in the selected USDA record.',
                  style: TextStyle(color: secondaryGreen, fontSize: 11),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: isSaving ? null : saveCustomMeal,
              icon: isSaving
                  ? const SizedBox(
                      height: 18,
                      width: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.save_outlined, size: 20),
              label: Text(
                isSaving ? 'Saving...' : 'Save Custom Meal',
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryGreen,
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 50),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }

  Future<void> editSavedMeal(Map<String, dynamic> meal) async {
    final mealId = meal['id']?.toString() ?? '';
    if (mealId.isEmpty) return;

    final isCustom = meal['mealKind'] == 'custom';

    final gramsController = TextEditingController(
      text: toDouble(meal['grams']).toStringAsFixed(0),
    );

    String mealType = meal['mealType']?.toString() ?? 'Breakfast';

    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text('Edit Meal'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: gramsController,
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      decoration: const InputDecoration(
                        labelText: 'Quantity (g)',
                      ),
                    ),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      value: mealType,
                      decoration: const InputDecoration(labelText: 'Meal type'),
                      items: mealTypes.map((type) {
                        return DropdownMenuItem(value: type, child: Text(type));
                      }).toList(),
                      onChanged: (value) {
                        if (value != null) {
                          setDialogState(() {
                            mealType = value;
                          });
                        }
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () {
                    final grams = double.tryParse(gramsController.text.trim());

                    if (grams == null || !grams.isFinite || grams <= 0) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Enter a valid quantity.'),
                        ),
                      );
                      return;
                    }

                    Navigator.pop(dialogContext, {
                      'grams': grams,
                      'mealType': mealType,
                    });
                  },
                  child: const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );

    gramsController.dispose();

    if (result == null || !mounted) return;

    final newGrams = result['grams'] as double;
    final newMealType = result['mealType'] as String;
    final oldGrams = toDouble(meal['grams']);

    if (oldGrams <= 0) return;

    final factor = newGrams / oldGrams;

    try {
      if (isCustom) {
        final components = (meal['components'] as List? ?? [])
            .whereType<Map>()
            .map((item) => Map<String, dynamic>.from(item))
            .map((item) {
              item['grams'] = toDouble(item['grams']) * factor;
              item['calories'] = toDouble(item['calories']) * factor;
              item['protein'] = toDouble(item['protein']) * factor;
              item['carbs'] = toDouble(item['carbs']) * factor;
              item['fat'] = toDouble(item['fat']) * factor;

              for (final nutrient in [
                'fiber',
                'sugar',
                'saturatedFat',
                'sodium',
              ]) {
                if (item[nutrient] is num) {
                  item[nutrient] = toDouble(item[nutrient]) * factor;
                }
              }

              return item;
            })
            .toList();

        await mealService.updateCustomMeal(
          mealId: mealId,
          mealType: newMealType,
          components: components,
          grams: newGrams,
          calories: toDouble(meal['calories']) * factor,
          protein: toDouble(meal['protein']) * factor,
          carbs: toDouble(meal['carbs']) * factor,
          fat: toDouble(meal['fat']) * factor,
        );
      } else {
        await mealService.updateMeal(
          mealId: mealId,
          grams: newGrams,
          calories: toDouble(meal['calories']) * factor,
          protein: toDouble(meal['protein']) * factor,
          carbs: toDouble(meal['carbs']) * factor,
          fat: toDouble(meal['fat']) * factor,
          mealType: newMealType,
        );
      }

      await loadSavedMeals();

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Meal updated successfully!'),
          backgroundColor: primaryGreen,
        ),
      );
    } catch (e) {
      debugPrint('Could not update meal: $e');

      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Could not update meal: $e')));
    }
  }

  Widget buildSavedMealCard(Map<String, dynamic> meal) {
    final name = meal['foodName']?.toString() ?? 'Unknown food';
    final grams = toDouble(meal['grams']);
    final calories = toDouble(meal['calories']);
    final protein = toDouble(meal['protein']);
    final carbs = toDouble(meal['carbs']);
    final fat = toDouble(meal['fat']);
    final mealType = meal['mealType']?.toString() ?? 'Snack';
    final mealId = meal['id']?.toString() ?? '';

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor),
      ),
      child: ListTile(
        leading: const CircleAvatar(
          backgroundColor: lightGreen,
          child: Icon(Icons.restaurant, color: primaryGreen),
        ),
        title: Text(
          name,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            color: headingColor,
          ),
        ),
        subtitle: Text(
          '$mealType • ${grams.toStringAsFixed(0)} g\n'
          '${calories.toStringAsFixed(1)} kcal'
          ' | P ${protein.toStringAsFixed(1)} g'
          ' | C ${carbs.toStringAsFixed(1)} g'
          ' | F ${fat.toStringAsFixed(1)} g',
          style: const TextStyle(
            color: secondaryGreen,
            height: 1.5,
            fontSize: 12,
          ),
        ),
        isThreeLine: true,
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              tooltip: 'Edit meal',
              onPressed: mealId.isEmpty ? null : () => editSavedMeal(meal),
              icon: const Icon(Icons.edit_outlined, color: primaryGreen),
            ),
            IconButton(
              tooltip: 'Delete meal',
              onPressed: mealId.isEmpty ? null : () => deleteMeal(mealId),
              icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildIngredientsTab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        sectionTitle('Find your food', icon: Icons.search),
        const SizedBox(height: 7),
        const Text(
          'Search for ingredients and control the quantity in grams.',
          style: TextStyle(color: secondaryGreen, fontSize: 13),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: searchController,
                onSubmitted: (_) => searchFoods(),
                decoration: InputDecoration(
                  hintText: 'Search food in Arabic or English',
                  prefixIcon: const Icon(Icons.search, color: primaryGreen),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: const BorderSide(color: borderColor),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            IconButton(
              onPressed: searchFoods,
              icon: const Icon(Icons.search),
              style: IconButton.styleFrom(
                backgroundColor: primaryGreen,
                foregroundColor: Colors.white,
                minimumSize: const Size(50, 50),
              ),
            ),
          ],
        ),
        const SizedBox(height: 18),
        const Text(
          'Categories',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: headingColor,
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 42,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: categories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, index) {
              final category = categories[index];
              final selected = selectedCategory == category;

              return ChoiceChip(
                label: Text(category),
                selected: selected,
                selectedColor: primaryGreen,
                backgroundColor: Colors.white,
                side: BorderSide(color: selected ? primaryGreen : borderColor),
                labelStyle: TextStyle(
                  color: selected ? Colors.white : headingColor,
                  fontSize: 12,
                ),
                onSelected: (_) => selectCategory(category),
              );
            },
          ),
        ),
        const SizedBox(height: 18),
        if (isInitializing || isLoading)
          const Center(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: CircularProgressIndicator(color: primaryGreen),
            ),
          )
        else if (errorMessage != null)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFFFEBEE),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Text(
              errorMessage!,
              style: const TextStyle(color: Color(0xFFB3261E)),
            ),
          )
        else if (visibleFoods.isEmpty)
          const Padding(
            padding: EdgeInsets.all(20),
            child: Center(
              child: Text(
                'No foods found. Try another search or category.',
                textAlign: TextAlign.center,
                style: TextStyle(color: secondaryGreen),
              ),
            ),
          )
        else
          LayoutBuilder(
            builder: (context, constraints) {
              final width = constraints.maxWidth;
              int columns = 1;

              if (width >= 1000) {
                columns = 3;
              } else if (width >= 620) {
                columns = 2;
              }

              final displayedCount = visibleFoods.length < displayedFoodsCount
                  ? visibleFoods.length
                  : displayedFoodsCount;

              return Column(
                children: [
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: displayedCount,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: columns,
                      crossAxisSpacing: 14,
                      mainAxisSpacing: 10,
                      mainAxisExtent: 450,
                    ),
                    itemBuilder: (context, index) {
                      return buildFoodCard(visibleFoods[index]);
                    },
                  ),

                  if (displayedCount < visibleFoods.length)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      child: Center(
                        child: isLoadingMore
                            ? const CircularProgressIndicator(
                                color: primaryGreen,
                              )
                            : SizedBox(
                                width: double.infinity,
                                child: OutlinedButton(
                                  onPressed: () async {
                                    setState(() {
                                      isLoadingMore = true;
                                    });

                                    // Give Flutter time to display the loading indicator.
                                    await Future.delayed(
                                      const Duration(milliseconds: 300),
                                    );

                                    if (!mounted) return;

                                    setState(() {
                                      final remaining =
                                          visibleFoods.length -
                                          displayedFoodsCount;

                                      displayedFoodsCount += remaining < 30
                                          ? remaining
                                          : 30;

                                      isLoadingMore = false;
                                    });
                                  },
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: primaryGreen,
                                    side: const BorderSide(color: primaryGreen),
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 14,
                                    ),
                                  ),
                                  child: Text(
                                    'Load More Foods '
                                    '(${visibleFoods.length - displayedCount} remaining)',
                                  ),
                                ),
                              ),
                      ),
                    ),
                ],
              );
            },
          ),
      ],
    );
  }

  Widget buildSelectedTab() {
    if (selectedTab == 0) {
      return buildIngredientsTab();
    }

    return buildCustomMealTabBody();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: backgroundColor,
        foregroundColor: primaryGreen,
        elevation: 0,
        title: const Row(
          children: [
            Icon(Icons.eco, color: primaryGreen, size: 28),
            SizedBox(width: 9),
            Text(
              'Meal Analysis',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: primaryGreen,
                fontSize: 22,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: RefreshIndicator(
          color: primaryGreen,
          onRefresh: () async {
            if (selectedTab == 0) {
              await loadFoods(query: searchController.text.trim());
            }

            await loadSavedMeals();
          },
          child: LayoutBuilder(
            builder: (context, screenConstraints) {
              final screenWidth = screenConstraints.maxWidth;
              final horizontalPadding = screenWidth >= 900 ? 40.0 : 20.0;

              return ListView(
                padding: EdgeInsets.fromLTRB(
                  horizontalPadding,
                  10,
                  horizontalPadding,
                  30,
                ),
                children: [
                  sectionTitle(
                    'Calories by Meal',
                    icon: Icons.pie_chart_outline,
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Track your calories throughout the day',
                    style: TextStyle(color: secondaryGreen, fontSize: 13),
                  ),
                  const SizedBox(height: 15),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: 4,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: screenWidth >= 620 ? 4 : 2,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      mainAxisExtent: 82,
                    ),
                    itemBuilder: (context, index) {
                      final mealCards = [
                        {
                          'title': 'Breakfast',
                          'icon': Icons.free_breakfast_rounded,
                          'color': const Color(0xFFD97706),
                        },
                        {
                          'title': 'Lunch',
                          'icon': Icons.lunch_dining_rounded,
                          'color': const Color(0xFF16A34A),
                        },
                        {
                          'title': 'Dinner',
                          'icon': Icons.dinner_dining_rounded,
                          'color': const Color(0xFF2563EB),
                        },
                        {
                          'title': 'Snack',
                          'icon': Icons.cookie_rounded,
                          'color': const Color(0xFFDC2626),
                        },
                      ];

                      final item = mealCards[index];
                      final title = item['title'] as String;

                      return _mealCaloriesCard(
                        title,
                        getMealCalories(title),
                        item['icon'] as IconData,
                        item['color'] as Color,
                      );
                    },
                  ),
                  const SizedBox(height: 25),
                  Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: borderColor),
                    ),
                    child: Row(
                      children: List.generate(tabNames.length, (index) {
                        final selected = selectedTab == index;

                        return Expanded(
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                selectedTab = index;
                              });
                            },
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              padding: const EdgeInsets.symmetric(
                                vertical: 12,
                                horizontal: 3,
                              ),
                              decoration: BoxDecoration(
                                color: selected
                                    ? primaryGreen
                                    : Colors.transparent,
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: Column(
                                children: [
                                  Icon(
                                    tabIcons[index],
                                    color: selected
                                        ? Colors.white
                                        : secondaryGreen,
                                    size: 21,
                                  ),
                                  const SizedBox(height: 5),
                                  Text(
                                    tabNames[index],
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: selected
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                      color: selected
                                          ? Colors.white
                                          : headingColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                  ),
                  const SizedBox(height: 22),
                  buildSelectedTab(),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
