import 'dart:async';

import 'package:flutter/material.dart';
import 'meal_data_service.dart';

const Color primaryGreen = Color(0xFF41644A);
const Color backgroundColor = Color(0xFFF7F8F2);
const Color headingColor = Color(0xFF26382B);
const Color lightGreen = Color(0xFFE5EEDD);

class SavedMealsScreen extends StatefulWidget {
  final MealDataService mealService;
  final List<Map<String, dynamic>> savedMeals;

  const SavedMealsScreen({
    super.key,
    required this.mealService,
    this.savedMeals = const [],
  });

  @override
  State<SavedMealsScreen> createState() => _SavedMealsScreenState();
}

class _SavedMealsScreenState extends State<SavedMealsScreen> {
  late MealDataService mealService;

  List<Map<String, dynamic>> savedMeals = [];

  final List<String> mealTypes = [
    'All Meals',
    'Breakfast',
    'Lunch',
    'Dinner',
    'Snack',
  ];

  String selectedMealType = 'All Meals';

  bool isLoading = true;
  bool isUpdatingMeal = false;

  StreamSubscription<List<Map<String, dynamic>>>? mealsSubscription;

  @override
  void initState() {
    super.initState();

    mealService = widget.mealService;
    savedMeals = List<Map<String, dynamic>>.from(widget.savedMeals);

    listenToMeals();
  }

  void listenToMeals() {
    mealsSubscription = mealService.watchMeals().listen(
      (result) {
        if (!mounted) return;

        setState(() {
          savedMeals = result;
          isLoading = false;
        });
      },
      onError: (error) {
        if (!mounted) return;

        setState(() {
          isLoading = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not load saved meals: $error')),
        );
      },
    );
  }

  @override
  void dispose() {
    mealsSubscription?.cancel();
    super.dispose();
  }

  double toDouble(dynamic value) {
    if (value is num) return value.toDouble();

    return double.tryParse(value?.toString() ?? '') ?? 0;
  }

  String formatNumber(dynamic value) {
    final number = toDouble(value);

    if (number == number.roundToDouble()) {
      return number.toInt().toString();
    }

    return number.toStringAsFixed(1);
  }

  List<Map<String, dynamic>> get filteredMeals {
    if (selectedMealType == 'All Meals') {
      return savedMeals;
    }

    return savedMeals.where((meal) {
      return meal['mealType']?.toString() == selectedMealType;
    }).toList();
  }

  bool isCustomMeal(Map<String, dynamic> meal) {
    return meal['mealKind']?.toString() == 'custom' ||
        meal['type']?.toString() == 'custom' ||
        meal['components'] is List;
  }

  Future<void> loadSavedMeals() async {
    if (!mounted) return;

    try {
      final result = await mealService.getMeals();

      if (!mounted) return;

      setState(() {
        savedMeals = result;
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
      });

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Could not load saved meals: $e')));
    }
  }

  Future<void> deleteMeal(Map<String, dynamic> meal) async {
    final mealId = meal['id']?.toString();

    if (mealId == null || mealId.isEmpty) return;

    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: const Text(
            'Delete Meal',
            style: TextStyle(color: headingColor, fontWeight: FontWeight.bold),
          ),
          content: const Text(
            'Are you sure you want to delete this meal?',
            style: TextStyle(color: headingColor),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext, false);
              },
              child: const Text(
                'Cancel',
                style: TextStyle(color: primaryGreen),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onPressed: () {
                Navigator.pop(dialogContext, true);
              },
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );

    if (shouldDelete != true) return;

    try {
      await mealService.deleteMeal(
        mealId,
        dateKey: meal['dateKey']?.toString(),
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Meal deleted successfully')),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Could not delete meal: $e')));
    }
  }

  // Edit an ordinary meal or open the Custom Meal editor.
  Future<void> editMeal(Map<String, dynamic> meal) async {
    final mealId = meal['id']?.toString();

    if (mealId == null || mealId.isEmpty) return;

    if (isCustomMeal(meal)) {
      await editCustomMealComponents(meal);
      return;
    }

    final gramsController = TextEditingController(
      text: formatNumber(meal['grams']),
    );

    final List<String> availableMealTypes = [
      'Breakfast',
      'Lunch',
      'Dinner',
      'Snack',
    ];

    String selectedType =
        availableMealTypes.contains(meal['mealType']?.toString())
        ? meal['mealType'].toString()
        : 'Breakfast';

    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: Colors.white,
              surfaceTintColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              title: const Text(
                'Edit Meal',
                style: TextStyle(
                  color: headingColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 22,
                ),
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      meal['foodName']?.toString() ?? 'Meal',
                      style: const TextStyle(
                        color: primaryGreen,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Quantity (grams)',
                      style: TextStyle(
                        color: headingColor,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: gramsController,
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      cursorColor: primaryGreen,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: backgroundColor,
                        suffixText: 'g',
                        suffixStyle: const TextStyle(
                          color: primaryGreen,
                          fontWeight: FontWeight.w600,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: Colors.grey.shade300),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: Colors.grey.shade300),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(
                            color: primaryGreen,
                            width: 1.5,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Meal Type',
                      style: TextStyle(
                        color: headingColor,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      value: selectedType,
                      dropdownColor: Colors.white,
                      iconEnabledColor: primaryGreen,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: backgroundColor,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: Colors.grey.shade300),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(
                            color: primaryGreen,
                            width: 1.5,
                          ),
                        ),
                      ),
                      items: availableMealTypes.map((type) {
                        return DropdownMenuItem<String>(
                          value: type,
                          child: Text(
                            type,
                            style: const TextStyle(color: headingColor),
                          ),
                        );
                      }).toList(),
                      onChanged: (value) {
                        if (value == null) return;

                        setDialogState(() {
                          selectedType = value;
                        });
                      },
                    ),
                  ],
                ),
              ),
              actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(dialogContext);
                  },
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.grey.shade700,
                  ),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryGreen,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 22,
                      vertical: 12,
                    ),
                  ),
                  onPressed: () {
                    final newGrams = double.tryParse(
                      gramsController.text.trim(),
                    );

                    if (newGrams == null || newGrams <= 0) {
                      ScaffoldMessenger.of(dialogContext).showSnackBar(
                        const SnackBar(
                          content: Text(
                            'Enter a valid quantity greater than zero.',
                          ),
                        ),
                      );
                      return;
                    }

                    Navigator.pop(dialogContext, {
                      'grams': newGrams,
                      'mealType': selectedType,
                    });
                  },
                  child: const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );

    gramsController.dispose();

    if (result == null) return;

    final oldGrams = toDouble(meal['grams']);
    final newGrams = result['grams'] as double;

    if (oldGrams <= 0) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('The original quantity is invalid.')),
      );
      return;
    }

    final factor = newGrams / oldGrams;

    try {
      setState(() {
        isUpdatingMeal = true;
      });

      await mealService.updateMeal(
        mealId: mealId,
        grams: newGrams,
        calories: toDouble(meal['calories']) * factor,
        protein: toDouble(meal['protein']) * factor,
        carbs: toDouble(meal['carbs']) * factor,
        fat: toDouble(meal['fat']) * factor,
        mealType: result['mealType'] as String,
        dateKey: meal['dateKey']?.toString(),
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Meal updated successfully')),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Could not update meal: $e')));
    } finally {
      if (mounted) {
        setState(() {
          isUpdatingMeal = false;
        });
      }
    }
  }

  // Edit each Custom Meal component independently.
  Future<void> editCustomMealComponents(Map<String, dynamic> meal) async {
    final mealId = meal['id']?.toString();

    if (mealId == null || mealId.isEmpty) return;

    final rawComponents = meal['components'];

    if (rawComponents is! List || rawComponents.isEmpty) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No ingredients were found in this Custom Meal.'),
        ),
      );
      return;
    }

    final components = rawComponents.map((component) {
      return Map<String, dynamic>.from(component as Map);
    }).toList();

    final controllers = <TextEditingController>[];

    for (final component in components) {
      controllers.add(
        TextEditingController(text: formatNumber(component['grams'])),
      );
    }

    final newQuantities = await showDialog<List<double>>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: const Text(
            'Edit Custom Meal',
            style: TextStyle(
              color: headingColor,
              fontWeight: FontWeight.bold,
              fontSize: 21,
            ),
          ),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: List.generate(components.length, (index) {
                  final component = components[index];

                  final name =
                      component['foodName']?.toString() ?? 'Ingredient';

                  return Container(
                    margin: const EdgeInsets.only(bottom: 14),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: backgroundColor,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: lightGreen),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name,
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            color: headingColor,
                            fontSize: 15,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '${formatNumber(component['calories'])} kcal',
                          style: const TextStyle(
                            color: primaryGreen,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextField(
                          controller: controllers[index],
                          keyboardType: const TextInputType.numberWithOptions(
                            decimal: true,
                          ),
                          cursorColor: primaryGreen,
                          decoration: InputDecoration(
                            labelText: 'Quantity',
                            labelStyle: const TextStyle(color: primaryGreen),
                            suffixText: 'g',
                            suffixStyle: const TextStyle(
                              color: primaryGreen,
                              fontWeight: FontWeight.w600,
                            ),
                            filled: true,
                            fillColor: Colors.white,
                            isDense: true,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(
                                color: Colors.grey.shade300,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(
                                color: primaryGreen,
                                width: 1.5,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
              ),
            ),
          ),
          actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              style: TextButton.styleFrom(
                foregroundColor: Colors.grey.shade700,
              ),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryGreen,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 12,
                ),
              ),
              onPressed: () {
                final quantities = <double>[];

                for (final controller in controllers) {
                  final quantity = double.tryParse(controller.text.trim());

                  if (quantity == null || quantity <= 0) {
                    ScaffoldMessenger.of(dialogContext).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Every ingredient quantity must be greater than zero.',
                        ),
                      ),
                    );
                    return;
                  }

                  quantities.add(quantity);
                }

                Navigator.pop(dialogContext, quantities);
              },
              child: const Text('Save Changes'),
            ),
          ],
        );
      },
    );

    for (final controller in controllers) {
      controller.dispose();
    }

    if (newQuantities == null) return;

    final updatedComponents = <Map<String, dynamic>>[];

    double totalGrams = 0;
    double totalCalories = 0;
    double totalProtein = 0;
    double totalCarbs = 0;
    double totalFat = 0;

    const nutrientKeys = [
      'calories',
      'protein',
      'carbs',
      'fat',
      'fiber',
      'sugar',
      'saturatedFat',
      'sodium',
    ];

    for (int i = 0; i < components.length; i++) {
      final oldComponent = components[i];
      final updatedComponent = Map<String, dynamic>.from(oldComponent);

      final oldGrams = toDouble(oldComponent['grams']);
      final newGrams = newQuantities[i];

      if (oldGrams <= 0) {
        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('One ingredient has an invalid original quantity.'),
          ),
        );
        return;
      }

      final factor = newGrams / oldGrams;

      updatedComponent['grams'] = newGrams;

      // Nutrients are totals for the component's current quantity.
      for (final key in nutrientKeys) {
        if (oldComponent[key] is num) {
          updatedComponent[key] = toDouble(oldComponent[key]) * factor;
        }
      }

      updatedComponents.add(updatedComponent);

      totalGrams += newGrams;
      totalCalories += toDouble(updatedComponent['calories']);
      totalProtein += toDouble(updatedComponent['protein']);
      totalCarbs += toDouble(updatedComponent['carbs']);
      totalFat += toDouble(updatedComponent['fat']);
    }

    try {
      if (mounted) {
        setState(() {
          isUpdatingMeal = true;
        });
      }

      await mealService.updateCustomMeal(
        mealId: mealId,
        mealType: meal['mealType']?.toString() ?? 'Breakfast',
        components: updatedComponents,
        grams: totalGrams,
        calories: totalCalories,
        protein: totalProtein,
        carbs: totalCarbs,
        fat: totalFat,
        dateKey: meal['dateKey']?.toString(),
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Ingredient quantities and nutrition updated successfully',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not update Custom Meal: $e')),
      );
    } finally {
      if (mounted) {
        setState(() {
          isUpdatingMeal = false;
        });
      }
    }
  }

  Widget buildFilterChip(String type) {
    final isSelected = selectedMealType == type;

    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(type),
        selected: isSelected,
        selectedColor: primaryGreen,
        backgroundColor: Colors.white,
        labelStyle: TextStyle(
          color: isSelected ? Colors.white : headingColor,
          fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
        ),
        side: BorderSide(
          color: isSelected ? primaryGreen : Colors.grey.shade300,
        ),
        onSelected: (_) {
          setState(() {
            selectedMealType = type;
          });
        },
      ),
    );
  }

  Widget buildNutritionItem(String label, dynamic value, String unit) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(color: Colors.grey.shade600, fontSize: 11),
        ),
        const SizedBox(height: 3),
        Text(
          '${formatNumber(value)} $unit',
          style: const TextStyle(
            color: headingColor,
            fontWeight: FontWeight.w600,
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget buildMealCard(Map<String, dynamic> meal) {
    final name = meal['foodName']?.toString() ?? 'Meal';
    final mealType = meal['mealType']?.toString() ?? 'Meal';

    final components = meal['components'] is List
        ? List<Map<String, dynamic>>.from(
            (meal['components'] as List).map(
              (item) => Map<String, dynamic>.from(item as Map),
            ),
          )
        : <Map<String, dynamic>>[];

    final isCustom = isCustomMeal(meal);

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      elevation: 1,
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: Colors.grey.shade200),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: lightGreen,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    isCustom ? Icons.restaurant_menu : Icons.fastfood_outlined,
                    color: primaryGreen,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                          color: headingColor,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 9,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: lightGreen,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          mealType,
                          style: const TextStyle(
                            color: primaryGreen,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'Edit meal',
                  onPressed: isUpdatingMeal ? null : () => editMeal(meal),
                  icon: const Icon(Icons.edit_outlined, color: primaryGreen),
                ),
                IconButton(
                  tooltip: 'Delete meal',
                  onPressed: isUpdatingMeal ? null : () => deleteMeal(meal),
                  icon: const Icon(
                    Icons.delete_outline,
                    color: Colors.redAccent,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Icon(Icons.scale_outlined, size: 17, color: primaryGreen),
                const SizedBox(width: 6),
                Text(
                  '${formatNumber(meal['grams'])} g',
                  style: const TextStyle(
                    color: headingColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const Spacer(),
                Text(
                  '${formatNumber(meal['calories'])} kcal',
                  style: const TextStyle(
                    color: primaryGreen,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Divider(color: Colors.grey.shade200),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                buildNutritionItem('Protein', meal['protein'], 'g'),
                buildNutritionItem('Carbs', meal['carbs'], 'g'),
                buildNutritionItem('Fat', meal['fat'], 'g'),
              ],
            ),
            if (isCustom && components.isNotEmpty) ...[
              const SizedBox(height: 18),
              Divider(color: Colors.grey.shade200),
              const SizedBox(height: 10),
              const Row(
                children: [
                  Icon(Icons.restaurant, color: primaryGreen, size: 18),
                  SizedBox(width: 8),
                  Text(
                    'Ingredients',
                    style: TextStyle(
                      color: headingColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ...components.map((component) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 7),
                  child: Row(
                    children: [
                      Container(
                        width: 7,
                        height: 7,
                        decoration: const BoxDecoration(
                          color: primaryGreen,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Text(
                          component['foodName']?.toString() ?? 'Ingredient',
                          style: const TextStyle(
                            color: headingColor,
                            fontSize: 13,
                          ),
                        ),
                      ),
                      Text(
                        '${formatNumber(component['grams'])} g',
                        style: TextStyle(
                          color: Colors.grey.shade700,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        '${formatNumber(component['calories'])} kcal',
                        style: const TextStyle(
                          color: primaryGreen,
                          fontWeight: FontWeight.w600,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: backgroundColor,
        surfaceTintColor: backgroundColor,
        elevation: 0,
        title: const Text(
          'Saved Meals',
          style: TextStyle(color: headingColor, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh meals',
            onPressed: isLoading ? null : loadSavedMeals,
            icon: const Icon(Icons.refresh, color: primaryGreen),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 54,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: mealTypes.map(buildFilterChip).toList(),
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: isLoading
                  ? const Center(
                      child: CircularProgressIndicator(color: primaryGreen),
                    )
                  : filteredMeals.isEmpty
                  ? RefreshIndicator(
                      onRefresh: loadSavedMeals,
                      color: primaryGreen,
                      child: ListView(
                        physics: const AlwaysScrollableScrollPhysics(),
                        children: const [
                          SizedBox(height: 100),
                          Icon(
                            Icons.restaurant_menu,
                            size: 56,
                            color: Colors.grey,
                          ),
                          SizedBox(height: 16),
                          Center(
                            child: Text(
                              'No saved meals found.',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          SizedBox(height: 8),
                          Center(
                            child: Text(
                              'Your saved meals will appear here.',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: loadSavedMeals,
                      color: primaryGreen,
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                        physics: const AlwaysScrollableScrollPhysics(),
                        itemCount: filteredMeals.length,
                        itemBuilder: (context, index) {
                          return buildMealCard(filteredMeals[index]);
                        },
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
