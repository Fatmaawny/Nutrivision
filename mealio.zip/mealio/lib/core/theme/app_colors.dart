import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const Color primaryGreen = Color(0xFF2C5E3B);
  static const Color darkGreen = Color(0xFF1E3F29);
  static const Color background = Color(0xFFF5F7F0);
  static const Color secondaryGreenText = Color(0xFF5A735E);
  static const Color cream = Color(0xFFFFE8D8);
  static const Color terracotta = Color(0xFFE77B54);
  static const Color gold = Color(0xFFF0B84B);
  static const Color mint = Color(0xFFDCEEDB);

  static const Color water = Color(0xFF3B8FD9);
  static const Color waterLight = Color(0xFF6BB8F2);
  static const Color waterSoft = Color(0xFFE3F0FB);
}
