import 'package:flutter/material.dart';

/// Extra colors used by the login / register flow.
class AuthColors {
  AuthColors._();

  static const Color background = Color(0xFFF3EFEA);
  static const Color cream = Color(0xFFF9E4D4);
  static const Color terracotta = Color(0xFFC86D51);
  static const Color mutedGreen = Color(0xFF5A735E);
  static const Color accent = Color(0xFFC48B69);
  static const Color border = Color(0xFFE5DDD3);
  static const Color fieldBackground = Color(0xFFFAF8F4);
}
