
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'login_screen.dart';
import 'bmi_screen.dart';
import 'profile_screen.dart';
import 'meals_screen.dart';
import 'saved_meals_screen.dart';
import 'tips_screen.dart';
import '../service/meal_data_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final MealDataService mealService = MealDataService();

  String userName = 'Sarah';

  bool isLoading = true;
  bool isLoadingCalories = true;

  double calories = 0;
  double protein = 0;
  double carbs = 0;
  double fat = 0;

  double? dailyCalorieGoal;

  Timer? _dayRefreshTimer;

  int selectedIndex = 0;

  late AnimationController pageAnimationController;

  static const Color primaryGreen = Color(0xFF2C5E3B);
  static const Color darkGreen = Color(0xFF1E3F29);
  static const Color backgroundColor = Color(0xFFF5F7F0);
  static const Color secondaryGreenText = Color(0xFF5A735E);
  static const Color creamAsset = Color(0xFFFFE8D8);
  static const Color terracottaAsset = Color(0xFFE77B54);
  static const Color goldAsset = Color(0xFFF0B84B);
  static const Color mintAsset = Color(0xFFDCEEDB);

  double get remainingCalories {
    if (dailyCalorieGoal == null) return 0;
    return dailyCalorieGoal! - calories;
  }

  @override
  void initState() {
    super.initState();

    pageAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 550),
    );

    pageAnimationController.forward();

    loadUserData();
    loadCalories();
    startDayRefreshTimer();
  }

  @override
  void dispose() {
    _dayRefreshTimer?.cancel();
    pageAnimationController.dispose();
    super.dispose();
  }

  // DATE

  String get todayKey {
    final now = DateTime.now();

    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  void startDayRefreshTimer() {
    String previousDay = todayKey;

    _dayRefreshTimer = Timer.periodic(
      const Duration(minutes: 1),
          (timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }

        if (todayKey != previousDay) {
          previousDay = todayKey;
          loadCalories();
        }
      },
    );
  }

  // LOAD USER DATA

  Future<void> loadUserData() async {
    final user = auth.currentUser;

    if (user == null) {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
      return;
    }

    try {
      final document =
      await firestore.collection('users').doc(user.uid).get();

      final data = document.data() ?? {};

      final name = (data['name'] ??
          data['fullName'] ??
          user.displayName ??
          'Sarah')
          .toString()
          .trim();

      if (!mounted) return;

      setState(() {
        userName = name.isEmpty ? 'Sarah' : name;
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        userName = user.displayName ?? 'Sarah';
        isLoading = false;
      });
    }
  }

  // LOAD CALORIES AND NUTRITION

  Future<void> loadCalories() async {
    final user = auth.currentUser;

    if (user == null) {
      if (!mounted) return;

      setState(() {
        dailyCalorieGoal = null;
        calories = 0;
        protein = 0;
        carbs = 0;
        fat = 0;
        isLoadingCalories = false;
      });

      return;
    }

    if (mounted) {
      setState(() {
        isLoadingCalories = true;
      });
    }

    try {
      final document =
      await firestore.collection('users').doc(user.uid).get();

      final data = document.data() ?? {};

      final weight = BmiScreen.number(data['weight']);
      final height = BmiScreen.number(data['height']);
      final age = BmiScreen.number(data['age']);

      final gender = (data['gender'] ?? 'Female').toString();
      final activityLevel = data['activityLevel'];
      final healthGoal = (data['healthGoal'] ?? '').toString();

      double? calculatedGoal;

      if (weight > 0 && height > 0 && age > 0) {
        final result = BmiScreen.calculateCalories(
          weight: weight,
          height: height,
          age: age,
          gender: gender,
          activityLevel: activityLevel,
          healthGoal: healthGoal,
        );

        if (result > 0) {
          calculatedGoal = result;
        }
      }

      final meals = await mealService.getMeals();
      final totals = await mealService.calculateTotals(meals);

      if (!mounted) return;

      setState(() {
        dailyCalorieGoal = calculatedGoal;

        calories = BmiScreen.number(totals['calories']);
        protein = BmiScreen.number(totals['protein']);
        carbs = BmiScreen.number(totals['carbs']);
        fat = BmiScreen.number(totals['fat']);

        isLoadingCalories = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        dailyCalorieGoal = null;
        isLoadingCalories = false;
      });
    }
  }

  // PAGE NAVIGATION

  void changePage(int index) {
    if (index < 0 || index > 4) return;

    if (selectedIndex == index) {
      if (index == 0) {
        loadUserData();
        loadCalories();
      }
      return;
    }

    setState(() {
      selectedIndex = index;
    });

    if (index == 0) {
      pageAnimationController.forward(from: 0);
      loadUserData();
      loadCalories();
    }
  }

  // BMI

  void openBMI() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BmiScreen(),
      ),
    ).then((_) {
      if (!mounted) return;

      loadUserData();
      loadCalories();
    });
  }

  // LOGOUT

  Future<void> logout() async {
    await auth.signOut();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (_) => LoginScreen(),
      ),
          (route) => false,
    );
  }

  // DESKTOP HEADER

  Widget buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  width: 43,
                  height: 43,
                  decoration: BoxDecoration(
                    color: primaryGreen,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(
                        color: primaryGreen.withOpacity(0.2),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.eco_rounded,
                    color: Colors.white,
                    size: 26,
                  ),
                ),
                const SizedBox(width: 10),
                const Text(
                  'MEALIO',
                  style: TextStyle(
                    color: darkGreen,
                    fontSize: 23,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            Material(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              child: InkWell(
                onTap: logout,
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  padding: const EdgeInsets.all(11),
                  child: const Icon(
                    Icons.logout_rounded,
                    color: terracottaAsset,
                    size: 21,
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 25),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 450),
          switchInCurve: Curves.easeOutBack,
          switchOutCurve: Curves.easeIn,
          transitionBuilder: (child, animation) {
            return FadeTransition(
              opacity: animation,
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0, 0.18),
                  end: Offset.zero,
                ).animate(animation),
                child: child,
              ),
            );
          },
          child: Text(
            isLoading ? 'Hello there! 👋' : 'Hello, $userName! 👋',
            key: ValueKey(isLoading ? 'loading-name' : userName),
            style: const TextStyle(
              color: darkGreen,
              fontSize: 25,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          "Let's make today a healthy one!",
          style: TextStyle(
            color: secondaryGreenText,
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  // MOBILE HEADER

  Widget buildMobileHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [primaryGreen, Color(0xFF438B58)],
                ),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: primaryGreen.withOpacity(0.18),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: const Icon(
                Icons.eco_rounded,
                color: Colors.white,
                size: 25,
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'MEALIO',
              style: TextStyle(
                color: darkGreen,
                fontSize: 22,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
              ),
            ),
            const Spacer(),
            Material(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              child: InkWell(
                onTap: logout,
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: const Color(0xFFE8EDE5),
                    ),
                  ),
                  child: const Icon(
                    Icons.logout_rounded,
                    color: terracottaAsset,
                    size: 20,
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 25),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 400),
          child: Text(
            isLoading
                ? 'Hello there! 👋'
                : 'Hello, ${userName.split(' ').first}! 👋',
            key: ValueKey(isLoading ? 'loading-mobile' : userName),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: darkGreen,
              fontSize: 26,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          "Let's make today a healthy one!",
          style: TextStyle(
            color: secondaryGreenText,
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            const Icon(
              Icons.calendar_today_rounded,
              color: terracottaAsset,
              size: 14,
            ),
            const SizedBox(width: 7),
            Text(
              '${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}',
              style: const TextStyle(
                color: secondaryGreenText,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 6,
              ),
              decoration: BoxDecoration(
                color: mintAsset,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Row(
                children: [
                  Icon(
                    Icons.favorite_rounded,
                    size: 12,
                    color: primaryGreen,
                  ),
                  SizedBox(width: 5),
                  Text(
                    'Healthy lifestyle',
                    style: TextStyle(
                      color: primaryGreen,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  // REMAINING CALORIES LABEL

  Widget buildRemainingCalories({bool desktop = false}) {
    if (isLoadingCalories) {
      return Text(
        'Calculating remaining calories...',
        style: TextStyle(
          color: Colors.white.withOpacity(0.8),
          fontSize: desktop ? 10 : 11,
          fontWeight: FontWeight.w600,
        ),
      );
    }

    if (dailyCalorieGoal == null || dailyCalorieGoal! <= 0) {
      return Text(
        'Complete your profile to set your goal',
        style: TextStyle(
          color: Colors.white.withOpacity(0.85),
          fontSize: desktop ? 9 : 10,
          fontWeight: FontWeight.w600,
        ),
      );
    }

    final isOver = remainingCalories < 0;

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: desktop ? 9 : 10,
        vertical: desktop ? 6 : 7,
      ),
      decoration: BoxDecoration(
        color: isOver
            ? terracottaAsset.withOpacity(0.95)
            : Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.18),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isOver ? Icons.warning_amber_rounded : Icons.spa_rounded,
            color: Colors.white,
            size: desktop ? 13 : 15,
          ),
          const SizedBox(width: 5),
          Flexible(
            child: Text(
              isOver
                  ? 'Over by ${remainingCalories.abs().toStringAsFixed(0)} kcal'
                  : 'Remaining: ${remainingCalories.toStringAsFixed(0)} kcal',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.white,
                fontSize: desktop ? 10 : 11,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // CALORIES CARD


  Widget buildCaloriesPlateCard({bool desktop = false}) {
    final goal = dailyCalorieGoal;

    final progress = goal != null && goal > 0
        ? (calories / goal).clamp(0.0, 1.0).toDouble()
        : 0.0;

    final remaining = goal != null ? goal - calories : null;

    final String goalText;

    if (isLoadingCalories) {
      goalText = 'Calculating...';
    } else if (goal != null && goal > 0) {
      goalText = '${goal.toStringAsFixed(0)} kcal';
    } else {
      goalText = 'Complete profile';
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final isCompact = constraints.maxWidth < 340;

        final circleSize = desktop
            ? 105.0
            : isCompact
            ? 105.0
            : 124.0;

        // Increased mobile height to prevent RenderFlex overflow.
        final cardHeight = desktop ? 215.0 : 225.0;
        final cardPadding = desktop ? 13.0 : 17.0;

        Widget progressCircle() {
          return SizedBox(
            width: circleSize,
            height: circleSize,
            child: Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.12),
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.white.withOpacity(0.2),
                  width: 1.5,
                ),
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox.expand(
                    child: TweenAnimationBuilder<double>(
                      tween: Tween<double>(
                        begin: 0,
                        end: progress,
                      ),
                      duration: const Duration(milliseconds: 1100),
                      curve: Curves.easeOutCubic,
                      builder: (context, animatedProgress, child) {
                        return CircularProgressIndicator(
                          value: animatedProgress,
                          strokeWidth: 8,
                          strokeCap: StrokeCap.round,
                          backgroundColor:
                          Colors.white.withOpacity(0.2),
                          valueColor:
                          const AlwaysStoppedAnimation<Color>(
                            goldAsset,
                          ),
                        );
                      },
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(
                          isLoadingCalories
                              ? '...'
                              : calories.toStringAsFixed(0),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: desktop ? 22 : 26,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      const SizedBox(height: 2),
                      const Text(
                        'kcal eaten',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 9,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        }

        Widget remainingInfo() {
          if (goal == null || isLoadingCalories) {
            return const SizedBox.shrink();
          }

          final isOver = remaining! < 0;

          return Container(
            margin: EdgeInsets.only(top: desktop ? 5 : 6),
            padding: EdgeInsets.symmetric(
              horizontal: desktop ? 10 : 10,
              vertical: desktop ? 6 : 6,
            ),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.16),
              borderRadius: BorderRadius.circular(13),
              border: Border.all(
                color: Colors.white.withOpacity(0.22),
                width: 1,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: desktop ? 25 : 27,
                  height: desktop ? 25 : 27,
                  decoration: BoxDecoration(
                    color: isOver
                        ? terracottaAsset.withOpacity(0.9)
                        : goldAsset.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: Icon(
                    isOver
                        ? Icons.warning_amber_rounded
                        : Icons.local_fire_department_rounded,
                    color: Colors.white,
                    size: desktop ? 15 : 17,
                  ),
                ),
                SizedBox(width: desktop ? 7 : 7),
                Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        isOver
                            ? 'DAILY LIMIT EXCEEDED'
                            : 'CALORIES REMAINING',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: desktop ? 7 : 8,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.3,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        isOver
                            ? '${remaining!.abs().toStringAsFixed(0)} kcal over'
                            : '${remaining!.toStringAsFixed(0)} kcal left',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: isOver
                              ? const Color(0xFFFFD1B9)
                              : const Color(0xFFFFE8D8),
                          fontSize: desktop ? 13 : 14,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }

        return Container(
          height: cardHeight,
          padding: EdgeInsets.all(cardPadding),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [
                Color(0xFF193C27),
                Color(0xFF2C7045),
                Color(0xFF438B58),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(28),
            boxShadow: [
              BoxShadow(
                color: primaryGreen.withOpacity(0.25),
                blurRadius: 20,
                offset: const Offset(0, 9),
              ),
            ],
          ),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(
                right: -25,
                top: -45,
                child: Container(
                  width: 115,
                  height: 115,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'YOUR DAILY GOAL 🎯',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: desktop ? 9 : 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: desktop ? 4 : 6),
                        Text(
                          'Calories\nTracker',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: desktop ? 19 : 21,
                            fontWeight: FontWeight.w900,
                            height: 1.05,
                          ),
                        ),
                        SizedBox(height: desktop ? 4 : 6),
                        Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: desktop ? 8 : 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: terracottaAsset,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            goal == null
                                ? goalText
                                : 'Goal: $goalText',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: desktop ? 9 : 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        remainingInfo(),
                      ],
                    ),
                  ),
                  SizedBox(width: desktop ? 5 : 8),
                  progressCircle(),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  // SECTION TITLE

  Widget sectionTitle(
      String title,
      String subtitle,
      String emoji,
      ) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$title $emoji',
                style: const TextStyle(
                  color: darkGreen,
                  fontSize: 19,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: const TextStyle(
                  color: secondaryGreenText,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // NUTRITION CARD

  Widget nutritionCard({
    required String title,
    required String value,
    required String unit,
    required String emoji,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 9,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white,
            color.withOpacity(0.055),
          ],
        ),
        borderRadius: BorderRadius.circular(21),
        border: Border.all(
          color: color.withOpacity(0.22),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.07),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(13),
            ),
            alignment: Alignment.center,
            child: Text(
              emoji,
              style: const TextStyle(fontSize: 20),
            ),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: secondaryGreenText,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 3),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        value,
                        style: TextStyle(
                          color: color,
                          fontSize: 21,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(width: 3),
                      Text(
                        unit,
                        style: TextStyle(
                          color: color.withOpacity(0.8),
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // NUTRITION GRID

  Widget buildNutritionGrid() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth >= 900 ? 4 : 2;
        const spacing = 12.0;

        final itemWidth =
            (constraints.maxWidth - (spacing * (columns - 1))) / columns;

        final aspectRatio =
        constraints.maxWidth >= 900 ? 2.05 : 1.75;

        final itemHeight = itemWidth / aspectRatio;

        return Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: [
            SizedBox(
              width: itemWidth,
              height: itemHeight,
              child: nutritionCard(
                title: 'Protein',
                value: protein.toStringAsFixed(0),
                unit: 'g',
                emoji: '🥚',
                color: terracottaAsset,
              ),
            ),
            SizedBox(
              width: itemWidth,
              height: itemHeight,
              child: nutritionCard(
                title: 'Carbs',
                value: carbs.toStringAsFixed(0),
                unit: 'g',
                emoji: '🌾',
                color: primaryGreen,
              ),
            ),
            SizedBox(
              width: itemWidth,
              height: itemHeight,
              child: nutritionCard(
                title: 'Fat',
                value: fat.toStringAsFixed(0),
                unit: 'g',
                emoji: '🥑',
                color: goldAsset,
              ),
            ),
            SizedBox(
              width: itemWidth,
              height: itemHeight,
              child: nutritionCard(
                title: 'Calories',
                value: calories.toStringAsFixed(0),
                unit: 'kcal',
                emoji: '🔥',
                color: secondaryGreenText,
              ),
            ),
          ],
        );
      },
    );
  }

  // FEATURE CARD

  Widget featureCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    required Color color,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          height: 125,
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white,
                color.withOpacity(0.055),
              ],
            ),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: color.withOpacity(0.24),
            ),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.06),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 43,
                    height: 43,
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.13),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Icon(
                      icon,
                      color: color,
                      size: 24,
                    ),
                  ),
                  Icon(
                    Icons.arrow_outward_rounded,
                    color: color,
                    size: 19,
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: darkGreen,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: secondaryGreenText,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // FEATURE BUTTONS

  Widget buildFeatureButtons() {
    return Row(
      children: [
        Expanded(
          child: featureCard(
            icon: Icons.restaurant_menu_rounded,
            title: 'Meal Tracker',
            subtitle: 'Track your meals',
            onTap: () => changePage(1),
            color: terracottaAsset,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: featureCard(
            icon: Icons.monitor_weight_rounded,
            title: 'BMI Calculator',
            subtitle: 'Check your BMI',
            onTap: openBMI,
            color: primaryGreen,
          ),
        ),
      ],
    );
  }

  // HEALTHY REMINDER

  Widget buildHealthyReminder() {
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFFFFE8D8),
            Color(0xFFFFF1E7),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(23),
        border: Border.all(
          color: terracottaAsset.withOpacity(0.2),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 53,
            height: 53,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.7),
              borderRadius: BorderRadius.circular(17),
            ),
            child: const Center(
              child: Text(
                '💧',
                style: TextStyle(fontSize: 29),
              ),
            ),
          ),
          const SizedBox(width: 13),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Healthy Reminder',
                  style: TextStyle(
                    color: darkGreen,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  'Small choices daily make a big difference. Stay hydrated!',
                  style: TextStyle(
                    color: secondaryGreenText,
                    fontSize: 12,
                    height: 1.4,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // HOME ANIMATION

  Widget animatedHomeItem({
    required Widget child,
    required double start,
    required double end,
  }) {
    final animation = CurvedAnimation(
      parent: pageAnimationController,
      curve: Interval(
        start,
        end,
        curve: Curves.easeOutCubic,
      ),
    );

    return FadeTransition(
      opacity: animation,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.12),
          end: Offset.zero,
        ).animate(animation),
        child: child,
      ),
    );
  }

  // HOME CONTENT

  Widget buildHomeContent() {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth >= 900) {
          return buildDesktopHomeContent();
        }

        return buildMobileHomeContent();
      },
    );
  }

  // DESKTOP HOME

  Widget buildDesktopHomeContent() {
    return RefreshIndicator(
      onRefresh: () async {
        await loadUserData();
        await loadCalories();
      },
      color: primaryGreen,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(35, 30, 35, 40),
        children: [
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1400),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: buildHeader()),
                      const SizedBox(width: 20),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 17,
                          vertical: 14,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(17),
                          border: Border.all(
                            color: const Color(0xFFE4EADF),
                          ),
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.calendar_month_rounded,
                              color: primaryGreen,
                              size: 20,
                            ),
                            const SizedBox(width: 9),
                            Text(
                              '${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}',
                              style: const TextStyle(
                                color: darkGreen,
                                fontWeight: FontWeight.w800,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 30),

                  // WELCOME + CALORIES CARDS

                  LayoutBuilder(
                    builder: (context, constraints) {
                      final compact = constraints.maxWidth < 850;

                      Widget welcomeCard() {
                        return Container(
                          // FIX: Match the calories card height.
                          height: 215,
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [
                                Color(0xFF193C27),
                                Color(0xFF2C7045),
                                Color(0xFF438B58),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(28),
                            boxShadow: [
                              BoxShadow(
                                color: primaryGreen.withOpacity(0.17),
                                blurRadius: 22,
                                offset: const Offset(0, 9),
                              ),
                            ],
                          ),
                          child: Stack(
                            clipBehavior: Clip.none,
                            children: [
                              Positioned(
                                right: -12,
                                top: -35,
                                child: Container(
                                  width: 165,
                                  height: 165,
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.07),
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              ),
                              Positioned(
                                right: 75,
                                bottom: -65,
                                child: Container(
                                  width: 125,
                                  height: 125,
                                  decoration: BoxDecoration(
                                    color: terracottaAsset.withOpacity(0.2),
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 12,
                                      vertical: 5,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.13),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: const Text(
                                      'YOUR HEALTHY SPACE  ✨',
                                      style: TextStyle(
                                        color: Color(0xFFFFE8D8),
                                        fontSize: 10,
                                        letterSpacing: 1.2,
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Text(
                                    'Welcome back, ${userName.split(' ').first}!',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 22,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  const Text(
                                    'Every healthy choice brings you closer\nto a better version of yourself.',
                                    style: TextStyle(
                                      color: Colors.white70,
                                      fontSize: 12,
                                      height: 1.25,
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  const Row(
                                    children: [
                                      Icon(
                                        Icons.favorite_rounded,
                                        color: Color(0xFFFFB69B),
                                        size: 16,
                                      ),
                                      SizedBox(width: 7),
                                      Text(
                                        'Eat well. Feel good. Live better.',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 11,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      }

                      if (compact) {
                        return Column(
                          children: [
                            welcomeCard(),
                            const SizedBox(height: 16),
                            SizedBox(
                              height: 215,
                              child: buildCaloriesPlateCard(desktop: true),
                            ),
                          ],
                        );
                      }

                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Expanded(
                            flex: 6,
                            child: welcomeCard(),
                          ),
                          const SizedBox(width: 18),
                          Expanded(
                            flex: 4,
                            child: SizedBox(
                              height: 215,
                              child: buildCaloriesPlateCard(desktop: true),
                            ),
                          ),
                        ],
                      );
                    },
                  ),

                  const SizedBox(height: 34),

                  Row(
                    children: [
                      Container(
                        width: 43,
                        height: 43,
                        decoration: BoxDecoration(
                          color: const Color(0xFFE6EFDF),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(
                          Icons.analytics_rounded,
                          color: primaryGreen,
                          size: 23,
                        ),
                      ),
                      const SizedBox(width: 13),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Today's Nutrition",
                              style: TextStyle(
                                color: darkGreen,
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Your daily nutrition overview',
                              style: TextStyle(
                                color: secondaryGreenText.withOpacity(0.9),
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFE8D8),
                          borderRadius: BorderRadius.circular(13),
                        ),
                        child: const Text(
                          'DAILY STATS',
                          style: TextStyle(
                            color: Color(0xFFC86D51),
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.7,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 19),
                  buildNutritionGrid(),
                  const SizedBox(height: 35),

                  Row(
                    children: [
                      Container(
                        width: 43,
                        height: 43,
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFE8D8),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(
                          Icons.auto_awesome_rounded,
                          color: terracottaAsset,
                          size: 23,
                        ),
                      ),
                      const SizedBox(width: 13),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Explore Mealio',
                              style: TextStyle(
                                color: darkGreen,
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              'Everything you need for your healthy journey',
                              style: TextStyle(
                                color: secondaryGreenText,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 19),
                  buildFeatureButtons(),
                  const SizedBox(height: 28),
                  buildHealthyReminder(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // MOBILE HOME

  Widget buildMobileHomeContent() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFFF8F7F1),
            Color(0xFFF5F7F0),
            Color(0xFFF9F3EC),
          ],
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: RefreshIndicator(
          onRefresh: () async {
            await loadUserData();
            await loadCalories();
          },
          color: primaryGreen,
          backgroundColor: Colors.white,
          child: ListView(
            key: const PageStorageKey('mobile-home-list'),
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(18, 15, 18, 30),
            children: [
              animatedHomeItem(
                start: 0.0,
                end: 0.35,
                child: buildMobileHeader(),
              ),
              const SizedBox(height: 23),
              animatedHomeItem(
                start: 0.1,
                end: 0.5,
                child: buildCaloriesPlateCard(),
              ),
              const SizedBox(height: 28),
              animatedHomeItem(
                start: 0.2,
                end: 0.6,
                child: sectionTitle(
                  "Today's Nutrition",
                  'Your daily nutrition at a glance',
                  '🥗',
                ),
              ),
              const SizedBox(height: 15),
              animatedHomeItem(
                start: 0.3,
                end: 0.7,
                child: buildNutritionGrid(),
              ),
              const SizedBox(height: 29),
              animatedHomeItem(
                start: 0.4,
                end: 0.8,
                child: sectionTitle(
                  'Explore Mealio',
                  'Simple tools for your healthy journey',
                  '✨',
                ),
              ),
              const SizedBox(height: 15),
              animatedHomeItem(
                start: 0.5,
                end: 0.9,
                child: buildFeatureButtons(),
              ),
              const SizedBox(height: 23),
              animatedHomeItem(
                start: 0.6,
                end: 1.0,
                child: buildHealthyReminder(),
              ),
              const SizedBox(height: 12),
              const Center(
                child: Text(
                  'Made with 💚 for a healthier you',
                  style: TextStyle(
                    color: secondaryGreenText,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // PAGE CONTENT

  Widget buildSelectedPage() {
    switch (selectedIndex) {
      case 0:
        return buildHomeContent();

      case 1:
        return MealsScreen();

      case 2:
        return SavedMealsScreen(
          mealService: mealService,
        );

      case 3:
        return TipsScreen();

      case 4:
        return const ProfileScreen();

      default:
        return buildHomeContent();
    }
  }

  // DESKTOP SIDE NAVIGATION

  Widget buildDesktopNavigation() {
    final items = [
      {'icon': Icons.home_rounded, 'label': 'Home'},
      {'icon': Icons.restaurant_menu_rounded, 'label': 'Meals'},
      {'icon': Icons.bookmark_rounded, 'label': 'Saved Meals'},
      {'icon': Icons.tips_and_updates_rounded, 'label': 'Healthy Tips'},
      {'icon': Icons.person_rounded, 'label': 'Profile'},
    ];

    return Container(
      width: 255,
      margin: const EdgeInsets.fromLTRB(18, 18, 0, 18),
      padding: const EdgeInsets.fromLTRB(17, 25, 17, 18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF193C27),
            Color(0xFF245438),
            Color(0xFF2C5E3B),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            color: darkGreen.withOpacity(0.17),
            blurRadius: 24,
            offset: const Offset(5, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(7, 0, 7, 35),
            child: Row(
              children: [
                Container(
                  width: 45,
                  height: 45,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.13),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.15),
                    ),
                  ),
                  child: const Icon(
                    Icons.eco_rounded,
                    color: Color(0xFFFFE8D8),
                    size: 26,
                  ),
                ),
                const SizedBox(width: 11),
                const Text(
                  'MEALIO',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 21,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.4,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 12, bottom: 14),
            child: Text(
              'MAIN MENU',
              style: TextStyle(
                color: Colors.white.withOpacity(0.48),
                fontSize: 10,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.6,
              ),
            ),
          ),
          ...List.generate(items.length, (index) {
            final selected = selectedIndex == index;

            return Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => changePage(index),
                  borderRadius: BorderRadius.circular(16),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    curve: Curves.easeOutCubic,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 13,
                      vertical: 15,
                    ),
                    decoration: BoxDecoration(
                      color: selected
                          ? const Color(0xFFFFE8D8)
                          : Colors.white.withOpacity(0.045),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: selected
                            ? const Color(0xFFFFE8D8)
                            : Colors.white.withOpacity(0.07),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          items[index]['icon'] as IconData,
                          size: 21,
                          color: selected
                              ? darkGreen
                              : Colors.white.withOpacity(0.8),
                        ),
                        const SizedBox(width: 13),
                        Expanded(
                          child: Text(
                            items[index]['label'] as String,
                            style: TextStyle(
                              color: selected
                                  ? darkGreen
                                  : Colors.white.withOpacity(0.85),
                              fontSize: 12,
                              fontWeight: selected
                                  ? FontWeight.w900
                                  : FontWeight.w600,
                            ),
                          ),
                        ),
                        if (selected)
                          const Icon(
                            Icons.arrow_forward_ios_rounded,
                            size: 13,
                            color: terracottaAsset,
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }),
          const Spacer(),

          // HEALTH CARD

          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [
                  Color(0xFFE77B54),
                  Color(0xFFC86D51),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Stack(
              children: [
                Positioned(
                  right: -15,
                  top: -20,
                  child: Icon(
                    Icons.spa_rounded,
                    size: 80,
                    color: Colors.white.withOpacity(0.12),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      Icons.favorite_rounded,
                      color: Colors.white,
                      size: 24,
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Healthy habits,\nhappy life!',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        height: 1.4,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 7),
                    Text(
                      'One step at a time.',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 17),

          // LOGOUT

          Material(
            color: Colors.white.withOpacity(0.09),
            borderRadius: BorderRadius.circular(15),
            child: InkWell(
              onTap: logout,
              borderRadius: BorderRadius.circular(15),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 14,
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.logout_rounded,
                      color: Color(0xFFFFB69B),
                      size: 20,
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'Log out',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // MOBILE WAVE BOTTOM NAVIGATION

  Widget buildBottomNavigation() {
    final items = [
      {'icon': Icons.home_rounded, 'label': 'Home'},
      {'icon': Icons.restaurant_menu_rounded, 'label': 'Meals'},
      {'icon': Icons.bookmark_rounded, 'label': 'Saved'},
      {'icon': Icons.tips_and_updates_rounded, 'label': 'Tips'},
      {'icon': Icons.person_rounded, 'label': 'Profile'},
    ];

    return SafeArea(
      top: false,
      child: Container(
        height: 86,
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: darkGreen.withOpacity(0.09),
              blurRadius: 20,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final itemWidth = constraints.maxWidth / items.length;
            final selectedCenter = itemWidth * (selectedIndex + 0.5);

            return Stack(
              clipBehavior: Clip.none,
              children: [
                Positioned.fill(
                  child: ClipPath(
                    clipper: WaveNavClipper(
                      selectedCenter: selectedCenter,
                    ),
                    child: Container(
                      color: Colors.white,
                    ),
                  ),
                ),
                Row(
                  children: List.generate(items.length, (index) {
                    final selected = selectedIndex == index;

                    return Expanded(
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () => changePage(index),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          curve: Curves.easeOutCubic,
                          padding: EdgeInsets.only(
                            top: selected ? 48 : 23,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (!selected)
                                Icon(
                                  items[index]['icon'] as IconData,
                                  color: secondaryGreenText.withOpacity(0.75),
                                  size: 22,
                                ),
                              if (selected)
                                Text(
                                  items[index]['label'] as String,
                                  style: const TextStyle(
                                    color: darkGreen,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              if (!selected) ...[
                                const SizedBox(height: 5),
                                AnimatedContainer(
                                  duration: const Duration(milliseconds: 250),
                                  width: 5,
                                  height: 5,
                                  decoration: BoxDecoration(
                                    color: terracottaAsset.withOpacity(0.8),
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
                ),
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 350),
                  curve: Curves.easeOutBack,
                  left: selectedCenter - 26,
                  top: 0,
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => changePage(selectedIndex),
                    child: Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [
                            Color(0xFF438B58),
                            Color(0xFF193C27),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.white,
                          width: 4,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: primaryGreen.withOpacity(0.22),
                            blurRadius: 13,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: Icon(
                        items[selectedIndex]['icon'] as IconData,
                        color: Colors.white,
                        size: 23,
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  // MAIN BUILD

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isDesktop = constraints.maxWidth >= 1000;
          final page = buildSelectedPage();

          if (isDesktop) {
            return Row(
              children: [
                buildDesktopNavigation(),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(28),
                      child: Container(
                        color: backgroundColor,
                        child: page,
                      ),
                    ),
                  ),
                ),
              ],
            );
          }

          return page;
        },
      ),
      bottomNavigationBar:
      MediaQuery.of(context).size.width >= 1000
          ? null
          : buildBottomNavigation(),
    );
  }
}

// WAVE NAVIGATION CLIPPER

class WaveNavClipper extends CustomClipper<Path> {
  final double selectedCenter;

  WaveNavClipper({
    required this.selectedCenter,
  });

  @override
  Path getClip(Size size) {
    final path = Path();

    if (size.width <= 0 || size.height <= 0) {
      return path;
    }

    final maxCenter =
    size.width - 42.0 > 42.0 ? size.width - 42.0 : 42.0;

    final center = selectedCenter.clamp(42.0, maxCenter).toDouble();

    path.moveTo(0, 22);
    path.lineTo(center - 42, 22);

    path.cubicTo(
      center - 27,
      22,
      center - 30,
      0,
      center,
      0,
    );

    path.cubicTo(
      center + 30,
      0,
      center + 27,
      22,
      center + 42,
      22,
    );

    path.lineTo(size.width, 22);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(covariant WaveNavClipper oldClipper) {
    return oldClipper.selectedCenter != selectedCenter;
  }
}
