import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_ui_oauth_google/firebase_ui_oauth_google.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'register_screen.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with TickerProviderStateMixin {
  static const Color primaryGreen = Color(0xFF2C5E3B);
  static const Color darkGreen = Color(0xFF1E3F29);
  static const Color background = Color(0xFFF3EFEA);
  static const Color cream = Color(0xFFF9E4D4);
  static const Color terracotta = Color(0xFFC86D51);
  static const Color mutedGreen = Color(0xFF5A735E);
  static const Color accentColor = Color(0xFFC48B69);
  static const Color borderColor = Color(0xFFE5DDD3);
  static const Color fieldBackground = Color(0xFFFAF8F4);

  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  final emailFocusNode = FocusNode();
  final passwordFocusNode = FocusNode();

  bool hidePassword = true;
  bool isLoading = false;
  bool rememberMe = false;

  late AnimationController floatingController;
  late AnimationController entranceController;

  late Animation<double> logoAnimation;
  late Animation<double> cardAnimation;
  late Animation<double> textSlideAnimation;

  @override
  void initState() {
    super.initState();

    loadRememberMe();

    emailFocusNode.addListener(_onFocusChanged);
    passwordFocusNode.addListener(_onFocusChanged);

    floatingController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(reverse: true);

    entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );

    logoAnimation = CurvedAnimation(
      parent: entranceController,
      curve: const Interval(0, 0.65, curve: Curves.easeOutBack),
    );

    cardAnimation = CurvedAnimation(
      parent: entranceController,
      curve: const Interval(0.15, 1, curve: Curves.easeOutCubic),
    );

    textSlideAnimation = CurvedAnimation(
      parent: entranceController,
      curve: const Interval(0.3, 0.9, curve: Curves.easeOutQuart),
    );

    entranceController.forward();
  }

  void _onFocusChanged() {
    if (mounted) {
      setState(() {});
    }
  }

  void replayAnimations() {
    if (!mounted) return;

    entranceController.reset();
    entranceController.forward();
  }

  Future<void> loadRememberMe() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    if (!mounted) return;

    setState(() {
      rememberMe = prefs.getBool('rememberMe') ?? false;

      if (rememberMe) {
        emailController.text = prefs.getString('savedEmail') ?? '';
      }
    });
  }

  Future<void> saveRememberMe() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    await prefs.setBool('rememberMe', rememberMe);

    if (rememberMe) {
      await prefs.setString('savedEmail', emailController.text.trim());
    } else {
      await prefs.remove('savedEmail');
    }
  }

  Future<void> toggleRememberMe(bool? value) async {
    setState(() {
      rememberMe = value ?? false;
    });

    await saveRememberMe();
  }

  Future<void> saveEmailWhileTyping(String value) async {
    if (!rememberMe) return;

    SharedPreferences prefs = await SharedPreferences.getInstance();

    await prefs.setString('savedEmail', value.trim());
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();

    emailFocusNode.removeListener(_onFocusChanged);
    passwordFocusNode.removeListener(_onFocusChanged);

    emailFocusNode.dispose();
    passwordFocusNode.dispose();

    floatingController.dispose();
    entranceController.dispose();

    super.dispose();
  }

  Future<void> login() async {
    String email = emailController.text.trim();
    String password = passwordController.text;

    if (email.isEmpty || password.isEmpty) {
      showMessage('Please enter your email and password');
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      await saveRememberMe();

      if (!mounted) return;

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
        (route) => false,
      );
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;

      switch (e.code) {
        case 'user-not-found':
          showMessage('No account found with this email');
          break;

        case 'wrong-password':
        case 'invalid-credential':
          showMessage('Incorrect email or password');
          break;

        case 'invalid-email':
          showMessage('Please enter a valid email address');
          break;

        case 'too-many-requests':
          showMessage('Too many attempts. Please try again later');
          break;

        default:
          showMessage(e.message ?? 'Login failed');
      }
    } catch (e) {
      if (!mounted) return;

      showMessage('Something went wrong. Please try again');
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<void> resetPassword() async {
    String email = emailController.text.trim();

    if (email.isEmpty) {
      showMessage('Enter your email address first');
      return;
    }

    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);

      if (!mounted) return;

      showMessage('Password reset email sent');
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;

      showMessage(e.message ?? 'Could not send reset email');
    }
  }

  void showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: darkGreen,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  InputDecoration inputDecoration({
    required String hint,
    required IconData icon,
    Widget? suffixIcon,
  }) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: Color(0xFF89958F), fontSize: 14),
      prefixIcon: Icon(icon, color: darkGreen, size: 21),
      suffixIcon: suffixIcon,
      filled: true,
      fillColor: fieldBackground,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: borderColor),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: borderColor),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: primaryGreen, width: 1.6),
      ),
    );
  }

  Widget _buildAnimatedFieldGroup({required int index, required Widget child}) {
    double start = 0.35 + (index * 0.15);
    double end = 0.70 + (index * 0.15);

    Animation<double> fieldAnimation = CurvedAnimation(
      parent: entranceController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );

    return FadeTransition(
      opacity: fieldAnimation,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0.20, 0),
          end: Offset.zero,
        ).animate(fieldAnimation),
        child: child,
      ),
    );
  }

  Widget _buildFocusedField({
    required FocusNode focusNode,
    required Widget child,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: focusNode.hasFocus
            ? [
                BoxShadow(
                  color: primaryGreen.withValues(alpha: 0.10),
                  blurRadius: 12,
                  spreadRadius: 1,
                ),
              ]
            : [],
      ),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            double width = constraints.maxWidth;
            double height = constraints.maxHeight;

            bool isDesktop = width >= 900;
            bool isTablet = width >= 600 && width < 900;
            bool isSmallMobile = width < 360;

            double horizontalPadding = isDesktop
                ? 48
                : isTablet
                ? 32
                : 20;

            double logoScale = isSmallMobile ? 0.82 : 1.0;

            return Stack(
              children: [
                _buildBackground(width, height),
                SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  keyboardDismissBehavior:
                      ScrollViewKeyboardDismissBehavior.onDrag,
                  padding: EdgeInsets.symmetric(
                    horizontal: horizontalPadding,
                    vertical: 24,
                  ),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minHeight: height > 48 ? height - 48 : height,
                    ),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 1100),
                        child: isDesktop
                            ? _buildDesktopLayout()
                            : _buildMobileLayout(logoScale, isTablet),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildMobileLayout(double logoScale, bool isTablet) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        ScaleTransition(
          scale: logoAnimation,
          child: FadeTransition(
            opacity: logoAnimation,
            child: Transform.scale(
              scale: logoScale,
              child: _buildLogo(centered: true),
            ),
          ),
        ),
        const SizedBox(height: 25),
        FadeTransition(
          opacity: cardAnimation,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0.18, 0),
              end: Offset.zero,
            ).animate(cardAnimation),
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: isTablet ? 480 : 420),
              child: _buildLoginCard(),
            ),
          ),
        ),
        const SizedBox(height: 20),
        FadeTransition(
          opacity: cardAnimation,
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.favorite_rounded, size: 14, color: terracotta),
              SizedBox(width: 6),
              Text(
                'Eat well. Live fully.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13,
                  color: mutedGreen,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDesktopImage() {
    return FadeTransition(
      opacity: logoAnimation,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(-0.12, 0),
          end: Offset.zero,
        ).animate(logoAnimation),
        child: Image.asset(
          'assets/images/Secure login-rafiki.png',
          width: 520,
          height: 500,
          fit: BoxFit.contain,
          errorBuilder: (context, error, stackTrace) {
            return const Icon(
              Icons.image_not_supported_rounded,
              size: 100,
              color: primaryGreen,
            );
          },
        ),
      ),
    );
  }

  Widget _buildDesktopLayout() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          flex: 5,
          child: Padding(
            padding: const EdgeInsets.only(right: 35),
            child: Center(child: _buildDesktopImage()),
          ),
        ),
        const SizedBox(width: 25),
        Expanded(
          flex: 5,
          child: FadeTransition(
            opacity: cardAnimation,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.18, 0),
                end: Offset.zero,
              ).animate(cardAnimation),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 460),
                child: _buildLoginCard(),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLogo({bool centered = false}) {
    return Column(
      crossAxisAlignment: centered
          ? CrossAxisAlignment.center
          : CrossAxisAlignment.start,
      children: [
        AnimatedBuilder(
          animation: floatingController,
          builder: (context, child) {
            double movement =
                math.sin(floatingController.value * math.pi * 2) * 10;

            return Transform.translate(
              offset: Offset(0, -movement),
              child: child,
            );
          },
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: primaryGreen.withValues(alpha: 0.22),
                  blurRadius: 40,
                  spreadRadius: 5,
                  offset: const Offset(0, 15),
                ),
              ],
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 125,
                  height: 125,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: primaryGreen, width: 5),
                    color: Colors.white.withValues(alpha: 0.4),
                  ),
                ),
                Container(
                  width: 100,
                  height: 100,
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      'assets/images/Secure login-rafiki.png',
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) {
                        return const Icon(
                          Icons.image_not_supported_rounded,
                          size: 40,
                          color: primaryGreen,
                        );
                      },
                    ),
                  ),
                ),
                Positioned(
                  right: 0,
                  top: 5,
                  child: _foodBubble(Icons.eco_rounded, primaryGreen),
                ),
                Positioned(
                  left: 0,
                  bottom: 15,
                  child: _foodBubble(Icons.favorite_rounded, terracotta),
                ),
                Positioned(
                  right: 5,
                  bottom: 0,
                  child: _foodBubble(Icons.spa_rounded, accentColor),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'Mealio',
          textAlign: centered ? TextAlign.center : TextAlign.start,
          style: const TextStyle(
            fontSize: 29,
            fontWeight: FontWeight.w800,
            color: darkGreen,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'Eat Smart, Live Healthy.',
          textAlign: centered ? TextAlign.center : TextAlign.start,
          style: const TextStyle(
            fontSize: 12,
            color: mutedGreen,
            letterSpacing: 0.4,
          ),
        ),
      ],
    );
  }

  Widget _foodBubble(IconData icon, Color color) {
    return Container(
      width: 35,
      height: 35,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Icon(icon, color: color, size: 19),
    );
  }

  Widget _buildLoginCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 27),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(27),
        border: Border.all(color: const Color(0xFFE9E3DA)),
        boxShadow: [
          BoxShadow(
            color: darkGreen.withValues(alpha: 0.08),
            blurRadius: 28,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'Welcome Back!',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 23,
              fontWeight: FontWeight.bold,
              color: darkGreen,
            ),
          ),
          const SizedBox(height: 7),
          const Text(
            'Sign in to continue your healthy journey.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: mutedGreen),
          ),
          const SizedBox(height: 25),
          _buildAnimatedFieldGroup(
            index: 0,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildLabel('Email address'),
                const SizedBox(height: 7),
                _buildFocusedField(
                  focusNode: emailFocusNode,
                  child: TextField(
                    controller: emailController,
                    focusNode: emailFocusNode,
                    keyboardType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,
                    onChanged: saveEmailWhileTyping,
                    onSubmitted: (_) {
                      passwordFocusNode.requestFocus();
                    },
                    decoration: inputDecoration(
                      hint: 'Enter your email',
                      icon: Icons.email_outlined,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 17),
          _buildAnimatedFieldGroup(
            index: 1,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildLabel('Password'),
                const SizedBox(height: 7),
                _buildFocusedField(
                  focusNode: passwordFocusNode,
                  child: TextField(
                    controller: passwordController,
                    focusNode: passwordFocusNode,
                    obscureText: hidePassword,
                    textInputAction: TextInputAction.done,
                    onSubmitted: (_) {
                      if (!isLoading) {
                        login();
                      }
                    },
                    decoration: inputDecoration(
                      hint: 'Enter your password',
                      icon: Icons.lock_outline,
                      suffixIcon: IconButton(
                        onPressed: () {
                          setState(() {
                            hidePassword = !hidePassword;
                          });
                        },
                        icon: Icon(
                          hidePassword
                              ? Icons.visibility_off_outlined
                              : Icons.visibility_outlined,
                          color: mutedGreen,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Checkbox(
                    value: rememberMe,
                    activeColor: primaryGreen,
                    visualDensity: VisualDensity.compact,
                    onChanged: isLoading ? null : toggleRememberMe,
                  ),
                  const Text(
                    'Remember Me',
                    style: TextStyle(
                      color: mutedGreen,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              Flexible(
                child: TextButton(
                  onPressed: isLoading ? null : resetPassword,
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 5),
                  ),
                  child: const Text(
                    'Forgot Password?',
                    style: TextStyle(
                      color: primaryGreen,
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 7),
          SizedBox(
            height: 49,
            child: ElevatedButton(
              onPressed: isLoading ? null : login,
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryGreen,
                foregroundColor: Colors.white,
                elevation: 3,
                shadowColor: primaryGreen.withValues(alpha: 0.25),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: isLoading
                  ? const SizedBox(
                      height: 21,
                      width: 21,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Text(
                      'Login',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 17),
          Row(
            children: [
              const Expanded(child: Divider(color: borderColor)),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text(
                  'or',
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                ),
              ),
              const Expanded(child: Divider(color: borderColor)),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 46,
            width: double.infinity,
            child: GoogleSignInButton(
              loadingIndicator: const CircularProgressIndicator(),
              clientId:
                  "889480397679-anhbfcbtnj9b6i0i46nr8jgqp8qfmgpc.apps.googleusercontent.com",
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Flexible(
                child: Text(
                  "Don't have an account?",
                  style: TextStyle(color: mutedGreen, fontSize: 12),
                ),
              ),
              TextButton(
                onPressed: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const RegisterScreen(),
                    ),
                  );

                  replayAnimations();
                },
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 7),
                ),
                child: const Text(
                  'Sign Up',
                  style: TextStyle(
                    color: primaryGreen,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLabel(String label) {
    return Text(
      label,
      style: const TextStyle(
        fontWeight: FontWeight.w600,
        color: darkGreen,
        fontSize: 13,
      ),
    );
  }

  Widget _buildBackground(double width, double height) {
    return Positioned.fill(
      child: Stack(
        children: [
          Positioned(
            top: -65,
            right: -55,
            child: _animatedCircle(width > 650 ? 230 : 165, cream, 12, 15),
          ),
          Positioned(
            bottom: -70,
            left: -55,
            child: _animatedCircle(
              width > 650 ? 210 : 155,
              const Color(0xFFE5EEDD),
              -12,
              -15,
            ),
          ),
          Positioned(
            top: height * 0.25,
            left: width * 0.09,
            child: _floatingIcon(Icons.spa_rounded, 33),
          ),
          Positioned(
            bottom: height * 0.22,
            right: width * 0.08,
            child: _floatingIcon(Icons.eco_rounded, 38),
          ),
          Positioned(
            top: height * 0.70,
            left: width * 0.18,
            child: _floatingIcon(Icons.energy_savings_leaf_rounded, 25),
          ),
        ],
      ),
    );
  }

  Widget _animatedCircle(double size, Color color, double dx, double dy) {
    return AnimatedBuilder(
      animation: floatingController,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(
            dx * floatingController.value,
            dy * floatingController.value,
          ),
          child: child,
        );
      },
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      ),
    );
  }

  Widget _floatingIcon(IconData icon, double size) {
    return AnimatedBuilder(
      animation: floatingController,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, -floatingController.value * 12),
          child: child,
        );
      },
      child: Icon(
        icon,
        color: primaryGreen.withValues(alpha: 0.20),
        size: size,
      ),
    );
  }
}
